plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Állandó aláírókulcs (a Google-engedély ehhez a kulcshoz kötött).
// A GitHub Actions a titkos SIGNING_KEYSTORE_B64 / SIGNING_PASSWORD értékekből állítja elő.
val uploadKeystore = file("upload.jks")
val uploadPassword: String? = System.getenv("SIGNING_PASSWORD")
val hasUploadKey = uploadKeystore.exists() && !uploadPassword.isNullOrBlank()

android {
    namespace = "hu.elofizetes.figyelo"
    compileSdk = 35

    defaultConfig {
        applicationId = "hu.elofizetes.figyelo"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }

    signingConfigs {
        if (hasUploadKey) {
            create("upload") {
                storeFile = uploadKeystore
                storePassword = uploadPassword
                keyAlias = "app"
                keyPassword = uploadPassword
            }
        }
    }

    buildTypes {
        debug {
            if (hasUploadKey) signingConfig = signingConfigs.getByName("upload")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName(if (hasUploadKey) "upload" else "debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
