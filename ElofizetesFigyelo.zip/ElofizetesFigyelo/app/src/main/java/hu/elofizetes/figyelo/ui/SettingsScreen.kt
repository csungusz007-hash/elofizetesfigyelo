package hu.elofizetes.figyelo.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import hu.elofizetes.figyelo.SubsViewModel

private val DayOptions = listOf(1, 3, 7)

@Composable
fun SettingsScreen(vm: SubsViewModel, onEnableReminders: () -> Unit, onImport: () -> Unit) {
    val c = LocalAppColors.current
    val context = LocalContext.current
    val systemAllows = NotificationManagerCompat.from(context).areNotificationsEnabled()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item(key = "header") { LargeTitleHeader("Beállítások") }

        item(key = "h_notif") { SectionHeader("Értesítések") }
        item(key = "c_notif") {
            GroupCard {
                FormRow("Emlékeztető terhelés előtt") {
                    AppSwitch(
                        checked = vm.remindersOn,
                        onCheckedChange = { on -> if (on) onEnableReminders() else vm.setReminders(false) },
                    )
                }
                if (vm.remindersOn) {
                    InsetDivider()
                    Column(Modifier.padding(16.dp)) {
                        Text("Hány nappal előtte szóljunk?", fontSize = 15.sp, color = c.secondary)
                        Spacer(Modifier.height(10.dp))
                        SegmentedControl(
                            options = DayOptions.map { "$it nappal" },
                            selectedIndex = DayOptions.indexOf(vm.remindDays).coerceAtLeast(0),
                            onSelect = { vm.updateRemindDays(DayOptions[it]) },
                        )
                    }
                }
                if (vm.remindersOn && !systemAllows) {
                    InsetDivider()
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(
                            "Az értesítések ki vannak kapcsolva a telefon beállításaiban, ezért most nem tudunk szólni.",
                            fontSize = 15.sp,
                            color = c.danger,
                        )
                    }
                    ActionRow("Értesítési beállítások megnyitása", c.accent) {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                    }
                }
            }
        }
        item(key = "f_notif") {
            SectionFooter("A terhelés napján is szólunk, próbaidőnél pedig az utolsó előtti napon is.")
        }

        item(key = "h_import") { SectionHeader("Importálás") }
        item(key = "c_import") {
            GroupCard { ActionRow("Bankkivonat beolvasása", c.accent, onImport) }
        }
        item(key = "f_import") { SectionFooter(EXPORT_TIP) }

        item(key = "h_data") { SectionHeader("Adatok") }
        item(key = "c_data") {
            GroupCard {
                FormRow("Tárolás") { Text("Ezen a telefonon", fontSize = 17.sp, color = c.secondary) }
                InsetDivider()
                FormRow("Verzió") { Text("1.1", fontSize = 17.sp, color = c.secondary) }
            }
        }
        item(key = "f_data") {
            SectionFooter("Nincs fiók és nincs reklám. Az app nem kér internet-hozzáférést, így semmilyen adatot nem küld el.")
        }
    }
}
