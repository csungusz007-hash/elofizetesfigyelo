package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.elofizetes.figyelo.SubsViewModel
import hu.elofizetes.figyelo.data.Subscription
import hu.elofizetes.figyelo.data.dueText
import hu.elofizetes.figyelo.data.formatDate
import hu.elofizetes.figyelo.data.formatMoney
import hu.elofizetes.figyelo.data.totalsText
import java.time.LocalDate

private data class Entry(val sub: Subscription, val next: LocalDate, val days: Int, val trial: Boolean)

@Composable
fun ListScreen(
    vm: SubsViewModel,
    onAdd: () -> Unit,
    onOpen: (Subscription) -> Unit,
    onEnableReminders: () -> Unit,
) {
    val c = LocalAppColors.current
    val today = LocalDate.now()
    val entries = vm.subs
        .map { Entry(it, it.nextCharge(today), it.daysUntilNext(today), it.isInTrial(today)) }
        .sortedWith(compareBy<Entry>({ it.next }, { it.sub.name.lowercase() }))
    val trials = entries.filter { it.trial }
    val rest = entries.filterNot { it.trial }
    val soon = rest.filter { it.days <= 7 }
    val later = rest.filter { it.days > 7 }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item(key = "header") {
            LargeTitleHeader(
                title = "Előfizetések",
                subtitle = if (entries.isEmpty()) null
                else "Havonta ${totalsText(vm.subs, 1.0)} · évente ${totalsText(vm.subs, 12.0)}",
                action = {
                    IconButton(onClick = onAdd) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = "Előfizetés hozzáadása",
                            tint = c.accent,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                },
            )
        }

        if (entries.isEmpty()) {
            item(key = "empty") { EmptyState(onAdd) }
            return@LazyColumn
        }

        if (!vm.remindersOn && !vm.promptDismissed) {
            item(key = "prompt") {
                Column(Modifier.padding(top = 12.dp)) {
                    ReminderPrompt(onEnable = onEnableReminders, onDismiss = vm::dismissPrompt)
                }
            }
        }

        subSection(
            "Próbaidő", trials, today, onOpen,
            footer = "Ha nem kéred tovább, mondd le a próbaidő vége előtt.",
        )
        subSection("Következő 7 nap", soon, today, onOpen)
        subSection("Később", later, today, onOpen)
    }
}

private fun LazyListScope.subSection(
    title: String,
    rows: List<Entry>,
    today: LocalDate,
    onOpen: (Subscription) -> Unit,
    footer: String? = null,
) {
    if (rows.isEmpty()) return
    item(key = "h_$title") { SectionHeader(title) }
    item(key = "s_$title") {
        GroupCard {
            rows.forEachIndexed { i, e ->
                SubRow(e, today, onOpen)
                if (i < rows.lastIndex) InsetDivider(start = 70.dp)
            }
        }
    }
    if (footer != null) item(key = "f_$title") { SectionFooter(footer) }
}

@Composable
private fun SubRow(e: Entry, today: LocalDate, onOpen: (Subscription) -> Unit) {
    val c = LocalAppColors.current
    val s = e.sub
    val when_ = if (e.trial) "Próbaidő vége · ${formatDate(e.next, today)}"
    else "${s.cycle.label} · ${formatDate(e.next, today)}"
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClickLabel = "Szerkesztés", role = Role.Button) { onOpen(s) }
            .heightIn(min = 64.dp)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LetterTile(s.name, s.colorIndex)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(s.name, fontSize = 17.sp, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(when_, fontSize = 15.sp, color = c.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(formatMoney(s.price, s.currency), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = c.label)
            Spacer(Modifier.height(3.dp))
            DaysPill(e.days)
        }
    }
}

/** A hátralévő idő mindig szövegként is ott van; a szín csak kiemel. */
@Composable
private fun DaysPill(days: Int) {
    val c = LocalAppColors.current
    val urgent = days <= 3
    val fg = if (urgent) c.danger else c.secondary
    val bg = if (urgent) c.danger.copy(alpha = 0.12f) else Color.Transparent
    Text(
        dueText(days),
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = fg,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = if (urgent) 8.dp else 0.dp, vertical = 2.dp),
    )
}

@Composable
private fun EmptyState(onAdd: () -> Unit) {
    val c = LocalAppColors.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(c.accent.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.CreditCard, contentDescription = null, tint = c.accent, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Még nincs előfizetésed", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = c.label)
        Spacer(Modifier.height(8.dp))
        Text(
            "Vedd fel, amiért rendszeresen fizetsz. Megmutatjuk, mennyibe kerül összesen, " +
                "és szólunk, mielőtt levonják.",
            fontSize = 15.sp,
            color = c.secondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onAdd,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.accentFill, contentColor = Color.White),
            modifier = Modifier.heightIn(min = 50.dp),
        ) {
            Text("Előfizetés hozzáadása", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ReminderPrompt(onEnable: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalAppColors.current
    GroupCard {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(
                Icons.Outlined.NotificationsActive,
                contentDescription = null,
                tint = c.accent,
                modifier = Modifier.size(28.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Szóljunk a terhelések előtt?", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c.label)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Pár nappal előtte kapsz egy értesítést, hogy legyen időd lemondani, amit már nem használsz.",
                    fontSize = 15.sp,
                    color = c.secondary,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onEnable,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.accentFill, contentColor = Color.White),
                    ) { Text("Bekapcsolás", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                    TextButton(onClick = onDismiss) {
                        Text("Most nem", fontSize = 15.sp, color = c.accent)
                    }
                }
            }
        }
    }
}
