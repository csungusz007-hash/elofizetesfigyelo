package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Gmail-hozzáférés kérése a Google saját engedélyablakával, majd a levelek átnézése.
 * [busy] nem null, amíg az engedélykérés vagy a keresés fut.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GmailSheet(
    busy: String?,
    error: String?,
    onAllow: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = LocalAppColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = { if (busy == null) onDismiss() },
        sheetState = sheetState,
        containerColor = c.groupedBg,
        dragHandle = { BottomSheetDefaults.DragHandle(color = c.separator) },
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp)) {
                if (busy == null) {
                    TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterStart)) {
                        Text("Mégse", fontSize = 17.sp, color = c.accent)
                    }
                }
                Text(
                    "Gmail",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.label,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            if (busy != null) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator(color = c.accent, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(20.dp))
                    Text(busy, fontSize = 17.sp, color = c.label, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Számlákat, előfizetési és próbaidős leveleket keresek. Ez 1–2 percig is eltarthat.",
                        fontSize = 15.sp,
                        color = c.secondary,
                        textAlign = TextAlign.Center,
                    )
                }
                return@Column
            }

            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                Text(
                    "Átnézem az elmúlt egy év leveleit, és megkeresem az előfizetéseid számláit és a próbaidőket.",
                    fontSize = 15.sp,
                    color = c.secondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )

                SectionHeader("Mi fog történni?")
                GroupCard {
                    Text(
                        "1. Feljön a Google ablaka: válaszd ki a Gmail-fiókodat.\n" +
                            "2. Ha azt írja, hogy „A Google nem ellenőrizte ezt az alkalmazást”, koppints a " +
                            "Folytatás gombra. Ez azért van, mert az app még teszt üzemmódban fut.\n" +
                            "3. Engedélyezd, hogy az app olvashassa a leveleidet.",
                        fontSize = 15.sp,
                        color = c.label,
                        modifier = Modifier.padding(16.dp),
                    )
                }
                if (error != null) {
                    Text(
                        error,
                        fontSize = 15.sp,
                        color = c.danger,
                        modifier = Modifier.padding(start = 36.dp, end = 36.dp, top = 10.dp),
                    )
                }
                SectionFooter(
                    "Az app csak olvasni tudja a leveleidet, küldeni vagy törölni nem. A leveleket a telefon " +
                        "dolgozza fel, semmit nem küldünk tovább. Jelszót nem tárolunk, a hozzáférést a " +
                        "Google-fiókodban bármikor visszavonhatod."
                )

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onAllow,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accentFill, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(min = 50.dp),
                ) {
                    Text("Hozzáférés engedélyezése", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
