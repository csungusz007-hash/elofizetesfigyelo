package hu.elofizetes.figyelo.data

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Minden adat helyben, a telefonon marad: egy JSON-fájl és a beállítások. */
class Repository(context: Context) {
    private val file = File(context.filesDir, "subscriptions.json")
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): List<Subscription> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).mapNotNull { Subscription.fromJson(arr.getJSONObject(it)) }
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Subscription>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(file.parentFile, "subscriptions.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(arr.toString())
            tmp.delete()
        }
    }

    var remindersOn: Boolean
        get() = prefs.getBoolean("reminders_on", false)
        set(v) = prefs.edit().putBoolean("reminders_on", v).apply()

    var remindDays: Int
        get() = prefs.getInt("remind_days", 3)
        set(v) = prefs.edit().putInt("remind_days", v).apply()

    var promptDismissed: Boolean
        get() = prefs.getBoolean("prompt_dismissed", false)
        set(v) = prefs.edit().putBoolean("prompt_dismissed", v).apply()

    var notified: Set<String>
        get() = prefs.getStringSet("notified", emptySet())?.toSet() ?: emptySet()
        set(v) = prefs.edit().putStringSet("notified", v).apply()
}
