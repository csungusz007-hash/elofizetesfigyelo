package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class AppTab(val label: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    SUBS("Előfizetések", Icons.Outlined.CreditCard, Icons.Filled.CreditCard),
    OVERVIEW("Áttekintés", Icons.Outlined.PieChart, Icons.Filled.PieChart),
    SETTINGS("Beállítások", Icons.Outlined.Settings, Icons.Filled.Settings),
}

/** Alsó lapsáv: a lapok navigálnak, nem végeznek műveletet. */
@Composable
fun TabBar(current: AppTab, onSelect: (AppTab) -> Unit) {
    val c = LocalAppColors.current
    Column(Modifier.fillMaxWidth().background(c.bar)) {
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(c.separator))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(56.dp)) {
            AppTab.entries.forEach { t ->
                val selected = t == current
                val tint = if (selected) c.accent else c.secondary
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(t) }),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(
                        imageVector = if (selected) t.selectedIcon else t.icon,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier.size(26.dp),
                    )
                    Text(
                        t.label,
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        color = tint,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

/** Nagy cím, felette egy sor a nézet műveleteinek (pl. +). */
@Composable
fun LargeTitleHeader(
    title: String,
    subtitle: String? = null,
    action: (@Composable () -> Unit)? = null,
) {
    val c = LocalAppColors.current
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().height(52.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
        ) { action?.invoke() }
        Text(
            title,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = c.label,
            modifier = Modifier.semantics { heading() },
        )
        if (subtitle != null) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, fontSize = 15.sp, color = c.secondary, modifier = Modifier.padding(end = 12.dp))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun SectionHeader(text: String) {
    val c = LocalAppColors.current
    Text(
        text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = c.secondary,
        modifier = Modifier
            .padding(start = 36.dp, end = 36.dp, top = 22.dp, bottom = 7.dp)
            .semantics { heading() },
    )
}

@Composable
fun SectionFooter(text: String) {
    val c = LocalAppColors.current
    Text(
        text,
        fontSize = 13.sp,
        color = c.secondary,
        modifier = Modifier.padding(start = 36.dp, end = 36.dp, top = 7.dp),
    )
}

@Composable
fun GroupCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalAppColors.current
    Column(
        modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(c.card),
        content = content,
    )
}

@Composable
fun InsetDivider(start: Dp = 16.dp) {
    val c = LocalAppColors.current
    Box(Modifier.padding(start = start).fillMaxWidth().height(0.5.dp).background(c.separator))
}

/** Űrlapsor: címke balra, érték vagy vezérlő jobbra. */
@Composable
fun FormRow(
    label: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val c = LocalAppColors.current
    Row(
        modifier.fillMaxWidth().heightIn(min = 50.dp).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 17.sp, color = c.label)
        Spacer(Modifier.width(16.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { content() }
    }
}

@Composable
fun InlineField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    align: TextAlign = TextAlign.End,
    singleLine: Boolean = true,
) {
    val c = LocalAppColors.current
    BasicTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.fillMaxWidth().semantics { contentDescription = label },
        singleLine = singleLine,
        textStyle = TextStyle(fontSize = 17.sp, color = c.label, textAlign = align),
        cursorBrush = SolidColor(c.accent),
        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType,
            capitalization = if (keyboardType == KeyboardType.Text) KeyboardCapitalization.Sentences
            else KeyboardCapitalization.None,
        ),
        decorationBox = { inner ->
            Box(
                Modifier.fillMaxWidth(),
                contentAlignment = if (align == TextAlign.End) Alignment.CenterEnd else Alignment.CenterStart,
            ) {
                if (value.isEmpty()) Text(placeholder, fontSize = 17.sp, color = c.secondary)
                inner()
            }
        },
    )
}

/** iOS-szerű szegmentált vezérlő. */
@Composable
fun SegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalAppColors.current
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(c.fill)
            .padding(2.dp),
    ) {
        options.forEachIndexed { i, o ->
            val selected = i == selectedIndex
            val shape = RoundedCornerShape(7.dp)
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 36.dp)
                    .then(
                        if (selected) Modifier.shadow(1.dp, shape).background(c.card, shape)
                        else Modifier
                    )
                    .clip(shape)
                    .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(i) }),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    color = c.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
fun AppSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalAppColors.current
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = c.switchOn,
            checkedThumbColor = Color.White,
            checkedBorderColor = Color.Transparent,
            uncheckedTrackColor = c.fill,
            uncheckedThumbColor = Color.White,
            uncheckedBorderColor = Color.Transparent,
        ),
    )
}

/** Színes csempe a szolgáltatás kezdőbetűjével; dekoráció, a képernyőolvasó kihagyja. */
@Composable
fun LetterTile(name: String, colorIndex: Int, size: Dp = 40.dp) {
    val letter = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(paletteColor(colorIndex))
            .clearAndSetSemantics { },
        contentAlignment = Alignment.Center,
    ) {
        Text(letter, color = Color.White, fontSize = (size.value * 0.45f).sp, fontWeight = FontWeight.Bold)
    }
}

/** Sor, amelyre koppintva művelet történik (pl. törlés), középre igazított szöveggel. */
@Composable
fun ActionRow(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().heightIn(min = 50.dp).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, fontSize = 17.sp, color = color)
    }
}
