package hu.elofizetes.figyelo.data

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64

/**
 * Gmail olvasása a hivatalos Gmail API-val, csak olvasási engedéllyel (gmail.readonly).
 * A leveleket a telefon dolgozza fel, semmit nem küld tovább.
 */
object GmailApi {

    const val SCOPE = "https://www.googleapis.com/auth/gmail.readonly"
    private const val BASE = "https://gmail.googleapis.com/gmail/v1/users/me"

    class GmailError(message: String, val needsConsent: Boolean = false) : Exception(message)

    private val SENDERS = listOf(
        "netflix", "spotify", "apple.com", "google.com", "youtube", "openai", "anthropic", "disney", "hbo",
        "max.com", "microsoft", "xbox", "playstation", "skyshowtime", "amazon", "duolingo", "adobe",
        "canva", "dropbox", "linkedin", "tinder", "audible", "storytel", "deezer", "tidal", "rtl",
        "telekom", "yettel", "one.hu", "digi", "wolt", "revolut", "nintendo", "twitch", "paypal",
    )
    private val SUBJECT_WORDS = listOf(
        "receipt", "nyugta", "számla", "invoice", "subscription", "előfizetés", "trial", "próbaidő",
        "renew", "megújítás", "payment", "fizetés", "membership", "tagság",
    )

    private fun get(path: String, token: String): JSONObject {
        val conn = (URL(BASE + path).openConnection() as HttpURLConnection).apply {
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
            connectTimeout = 20_000
            readTimeout = 30_000
        }
        try {
            val code = conn.responseCode
            if (code == 401 || code == 403) {
                throw GmailError("A Google-engedély lejárt vagy nincs meg. Engedélyezd újra a hozzáférést.", needsConsent = true)
            }
            if (code !in 200..299) throw GmailError("A Gmail hibát jelzett ($code). Próbáld újra később.")
            return JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } catch (e: IOException) {
            throw GmailError("Nem sikerült kapcsolódni a Gmailhez. Ellenőrizd az internetkapcsolatot.")
        } finally {
            conn.disconnect()
        }
    }

    fun profileEmail(token: String): String? =
        runCatching { get("/profile", token).optString("emailAddress").takeIf { it.isNotBlank() } }.getOrNull()

    fun fetchMails(
        token: String,
        since: LocalDate,
        max: Int = 250,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ): Pair<List<MailItem>, Int> {
        val after = since.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
        val q = "after:$after (from:(" + SENDERS.joinToString(" OR ") + ") OR subject:(" +
            SUBJECT_WORDS.joinToString(" OR ") + "))"
        val ids = ArrayList<String>()
        var pageToken: String? = null
        do {
            val path = "/messages?maxResults=100&q=" + URLEncoder.encode(q, "UTF-8") +
                (pageToken?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
            val res = get(path, token)
            val arr = res.optJSONArray("messages")
            if (arr != null) for (i in 0 until arr.length()) ids += arr.getJSONObject(i).getString("id")
            pageToken = res.optString("nextPageToken").takeIf { it.isNotBlank() }
        } while (pageToken != null && ids.size < max)

        val take = ids.take(max)
        val out = ArrayList<MailItem>()
        take.forEachIndexed { i, id ->
            onProgress(i + 1, take.size)
            try {
                parse(get("/messages/$id?format=full", token))?.let { out += it }
            } catch (e: GmailError) {
                if (e.needsConsent) throw e
            } catch (e: Exception) {
                // egy hibás levél ne állítsa meg a többit
            }
        }
        return out to ids.size
    }

    // ---------- Levél feldolgozása ----------

    private fun header(headers: org.json.JSONArray?, name: String): String? {
        if (headers == null) return null
        for (i in 0 until headers.length()) {
            val h = headers.getJSONObject(i)
            if (h.optString("name").equals(name, ignoreCase = true)) return h.optString("value")
        }
        return null
    }

    private fun parse(msg: JSONObject): MailItem? {
        val payload = msg.optJSONObject("payload") ?: return null
        val headers = payload.optJSONArray("headers")
        val from = header(headers, "From").orEmpty()
        val subject = header(headers, "Subject").orEmpty()
        val millis = msg.optString("internalDate").toLongOrNull() ?: return null
        val date = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
        val plain = StringBuilder()
        val html = StringBuilder()
        collect(payload, plain, html, 0)
        val body = if (plain.isNotBlank()) plain.toString() else MailClassifier.htmlToText(html.toString())
        return MailItem(from, subject, date, body.take(8000))
    }

    private fun collect(part: JSONObject, plain: StringBuilder, html: StringBuilder, depth: Int) {
        if (depth > 8) return
        val mime = part.optString("mimeType").lowercase()
        val data = part.optJSONObject("body")?.optString("data").orEmpty()
        if (data.isNotEmpty() && (mime == "text/plain" || mime == "text/html")) {
            val charset = Regex("charset=\"?([A-Za-z0-9_-]+)").find(header(part.optJSONArray("headers"), "Content-Type").orEmpty())
                ?.groupValues?.get(1)
                ?.let { runCatching { Charset.forName(it) }.getOrNull() } ?: Charsets.UTF_8
            val text = runCatching { String(Base64.getUrlDecoder().decode(data.trimEnd('=')), charset) }.getOrNull().orEmpty()
            if (mime == "text/plain") plain.append(text).append('\n') else html.append(text).append('\n')
        }
        val parts = part.optJSONArray("parts") ?: return
        for (i in 0 until parts.length()) collect(parts.getJSONObject(i), plain, html, depth + 1)
    }
}
