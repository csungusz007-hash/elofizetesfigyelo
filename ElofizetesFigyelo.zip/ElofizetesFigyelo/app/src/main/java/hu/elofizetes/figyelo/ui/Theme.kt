package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Szemantikus színek, Apple-féle csoportosított listákhoz.
 * Kontrasztok: secondary #6C6C70 fehéren 5,1:1; accent #5856D6 fehéren 5,6:1;
 * danger #D70015 fehéren 5,6:1. Sötétben: secondary #AEAEB2 a #1C1C1E-n 7,6:1;
 * accent #8E8CFF 5,8:1.
 */
data class AppColors(
    val groupedBg: Color,
    val card: Color,
    val bar: Color,
    val label: Color,
    val secondary: Color,
    val separator: Color,
    val fill: Color,
    val accent: Color,
    val accentFill: Color,
    val danger: Color,
    val switchOn: Color,
)

val LightColors = AppColors(
    groupedBg = Color(0xFFF2F2F7),
    card = Color(0xFFFFFFFF),
    bar = Color(0xFFF9F9F9),
    label = Color(0xFF000000),
    secondary = Color(0xFF6C6C70),
    separator = Color(0xFFC6C6C8),
    fill = Color(0xFFE3E3E8),
    accent = Color(0xFF5856D6),
    accentFill = Color(0xFF5856D6),
    danger = Color(0xFFD70015),
    switchOn = Color(0xFF34C759),
)

val DarkColors = AppColors(
    groupedBg = Color(0xFF000000),
    card = Color(0xFF1C1C1E),
    bar = Color(0xFF161618),
    label = Color(0xFFFFFFFF),
    secondary = Color(0xFFAEAEB2),
    separator = Color(0xFF38383A),
    fill = Color(0xFF2C2C2E),
    accent = Color(0xFF8E8CFF),
    accentFill = Color(0xFF5E5CE6),
    danger = Color(0xFFFF6961),
    switchOn = Color(0xFF30D158),
)

/** Előfizetés-csempék színei; mindegyiken olvasható a fehér, félkövér betű (legalább 3:1). */
val Palette = listOf(
    0xFF5856D6, 0xFF0A6CFF, 0xFFE0352B, 0xFFC8650A, 0xFF248A3D,
    0xFF0E7C86, 0xFFD6336C, 0xFF636366, 0xFF8E3FB5,
).map { Color(it) }

fun paletteColor(index: Int): Color = Palette[((index % Palette.size) + Palette.size) % Palette.size]

val LocalAppColors = staticCompositionLocalOf { LightColors }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkColors else LightColors
    val base = if (dark) darkColorScheme() else lightColorScheme()
    val scheme = base.copy(
        primary = c.accentFill,
        onPrimary = Color.White,
        secondaryContainer = c.fill,
        background = c.groupedBg,
        surface = c.card,
        onSurface = c.label,
        onSurfaceVariant = c.secondary,
        surfaceContainerLow = c.groupedBg,
        surfaceContainer = c.card,
        surfaceContainerHigh = c.card,
        surfaceContainerHighest = c.card,
        outline = c.separator,
        outlineVariant = c.separator,
        error = c.danger,
    )
    CompositionLocalProvider(LocalAppColors provides c) {
        MaterialTheme(colorScheme = scheme) {
            CompositionLocalProvider(LocalContentColor provides c.label) {
                content()
            }
        }
    }
}
