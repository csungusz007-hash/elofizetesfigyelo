package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.elofizetes.figyelo.data.Category
import hu.elofizetes.figyelo.data.Currencies
import hu.elofizetes.figyelo.data.Cycle
import hu.elofizetes.figyelo.data.Presets
import hu.elofizetes.figyelo.data.Subscription
import hu.elofizetes.figyelo.data.currencySymbol
import hu.elofizetes.figyelo.data.formatDateLong
import hu.elofizetes.figyelo.data.formatPlain
import hu.elofizetes.figyelo.data.parsePrice
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID
import kotlin.random.Random

private const val DAY_MS = 86_400_000L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditSheet(
    initial: Subscription?,
    onDismiss: () -> Unit,
    onSave: (Subscription) -> Unit,
    onDelete: (Subscription) -> Unit,
) {
    val c = LocalAppColors.current
    val today = remember { LocalDate.now() }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf(initial?.name ?: "") }
    var priceText by remember { mutableStateOf(initial?.price?.let { formatPlain(it) } ?: "") }
    var currency by remember { mutableStateOf(initial?.currency ?: "HUF") }
    var cycle by remember { mutableStateOf(initial?.cycle ?: Cycle.MONTHLY) }
    var date by remember { mutableStateOf(initial?.nextCharge(today) ?: today.plusMonths(1)) }
    var trial by remember { mutableStateOf(initial?.isInTrial(today) ?: false) }
    var category by remember { mutableStateOf(initial?.category ?: Category.OTHER) }
    var colorIndex by remember { mutableIntStateOf(initial?.colorIndex ?: Random.nextInt(Palette.size)) }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var showDatePicker by remember { mutableStateOf(false) }

    val price = parsePrice(priceText)
    val valid = name.isNotBlank() && price != null && price >= 0.0

    fun close(after: () -> Unit) {
        scope.launch { sheetState.hide() }.invokeOnCompletion { after() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.groupedBg,
        dragHandle = { BottomSheetDefaults.DragHandle(color = c.separator) },
    ) {
        Column(Modifier.fillMaxWidth().imePadding()) {
            // Eszköztár: Mégse – cím – Mentés
            Box(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp)) {
                TextButton(onClick = { close(onDismiss) }, modifier = Modifier.align(Alignment.CenterStart)) {
                    Text("Mégse", fontSize = 17.sp, color = c.accent)
                }
                Text(
                    if (initial == null) "Új előfizetés" else "Szerkesztés",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.label,
                    modifier = Modifier.align(Alignment.Center),
                )
                TextButton(
                    enabled = valid,
                    onClick = {
                        val s = Subscription(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            name = name.trim(),
                            price = price ?: 0.0,
                            currency = currency,
                            cycle = cycle,
                            firstCharge = date,
                            category = category,
                            colorIndex = colorIndex,
                            trial = trial,
                            note = note.trim(),
                        )
                        close { onSave(s) }
                    },
                    modifier = Modifier.align(Alignment.CenterEnd),
                ) {
                    Text(
                        "Mentés",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (valid) c.accent else c.secondary,
                    )
                }
            }

            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 40.dp)) {

                // Gyors választás – gépelés helyett
                if (initial == null) {
                    SectionHeader("Gyakori szolgáltatások")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(Presets) { p ->
                            Chip(
                                text = p.name,
                                selected = name == p.name,
                                onClick = {
                                    name = p.name
                                    category = p.category
                                    colorIndex = p.colorIndex
                                },
                            )
                        }
                    }
                }

                SectionHeader("Alapadatok")
                GroupCard {
                    FormRow("Név") {
                        InlineField(name, { name = it }, "Pl. Netflix", label = "Név")
                    }
                    InsetDivider()
                    FormRow("Ár") {
                        InlineField(
                            priceText,
                            { t -> priceText = t.filter { it.isDigit() || it == ',' || it == '.' } },
                            "0 ${currencySymbol(currency)}",
                            label = "Ár",
                            keyboardType = KeyboardType.Decimal,
                        )
                    }
                    Box(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        SegmentedControl(
                            options = Currencies.map { currencySymbol(it) },
                            selectedIndex = Currencies.indexOf(currency).coerceAtLeast(0),
                            onSelect = { currency = Currencies[it] },
                        )
                    }
                }

                SectionHeader("Milyen gyakran?")
                GroupCard {
                    Box(Modifier.padding(16.dp)) {
                        SegmentedControl(
                            options = Cycle.entries.map { it.short },
                            selectedIndex = cycle.ordinal,
                            onSelect = { cycle = Cycle.entries[it] },
                        )
                    }
                    InsetDivider()
                    FormRow(
                        if (trial) "Próbaidő vége" else "Következő terhelés",
                        modifier = Modifier.clickable(role = Role.Button) { showDatePicker = true },
                    ) {
                        Text(formatDateLong(date), fontSize = 17.sp, color = c.accent)
                    }
                    InsetDivider()
                    FormRow("Ingyenes próbaidő") {
                        AppSwitch(checked = trial, onCheckedChange = { trial = it })
                    }
                }
                SectionFooter(
                    if (trial) "Előtte többször is szólunk, hogy időben lemondhasd, ha nem kéred."
                    else "Ettől a naptól számoljuk előre a következő terheléseket."
                )

                SectionHeader("Kategória")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(Category.entries) { cat ->
                        Chip(cat.label, selected = cat == category, onClick = { category = cat })
                    }
                }

                SectionHeader("Szín")
                GroupCard {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                    ) {
                        Palette.forEachIndexed { i, col ->
                            ColorDot(col, selected = i == colorIndex, index = i) { colorIndex = i }
                        }
                    }
                }

                SectionHeader("Megjegyzés")
                GroupCard {
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                        InlineField(
                            note, { note = it },
                            "Pl. családi csomag, a bankkártyáról vonják",
                            label = "Megjegyzés",
                            align = TextAlign.Start,
                            singleLine = false,
                        )
                    }
                }

                if (initial != null) {
                    Spacer(Modifier.height(28.dp))
                    GroupCard {
                        ActionRow("Előfizetés törlése", c.danger) { close { onDelete(initial) } }
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = date.toEpochDay() * DAY_MS)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { date = LocalDate.ofEpochDay(it / DAY_MS) }
                    showDatePicker = false
                }) { Text("Kész", color = c.accent, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Mégse", color = c.accent) }
            },
        ) {
            DatePicker(state = state)
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalAppColors.current
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) c.accentFill else c.card)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) Color.White else c.label,
        )
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, index: Int, onClick: () -> Unit) {
    val c = LocalAppColors.current
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .semantics { contentDescription = "${index + 1}. szín" },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(30.dp)
                .then(if (selected) Modifier.border(2.dp, c.label.copy(alpha = 0.25f), CircleShape) else Modifier)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}
