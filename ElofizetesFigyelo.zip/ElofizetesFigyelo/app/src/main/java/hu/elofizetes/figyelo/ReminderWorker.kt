package hu.elofizetes.figyelo

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import hu.elofizetes.figyelo.data.Repository
import hu.elofizetes.figyelo.data.dueText
import hu.elofizetes.figyelo.data.formatDate
import hu.elofizetes.figyelo.data.formatMoney
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** Naponta reggel 9 körül megnézi, mi esedékes, és értesítést küld. */
class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        runCheck(applicationContext)
        return Result.success()
    }

    companion object {
        private const val CHANNEL = "charges"
        private const val WORK = "charge-reminders"

        fun schedule(context: Context, replace: Boolean) {
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(9, 0)
            if (!next.isAfter(now)) next = next.plusDays(1)
            val delay = Duration.between(now, next).toMinutes()
            val req = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK,
                if (replace) ExistingPeriodicWorkPolicy.UPDATE else ExistingPeriodicWorkPolicy.KEEP,
                req
            )
            if (replace) checkNow(context)
        }

        fun checkNow(context: Context) {
            WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<ReminderWorker>().build())
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK)
        }

        private fun ensureChannel(context: Context) {
            val nm = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL, "Közelgő terhelések", NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Szól az előfizetések levonása és a próbaidők vége előtt"
            }
            nm.createNotificationChannel(channel)
        }

        @SuppressLint("MissingPermission")
        fun runCheck(context: Context) {
            val repo = Repository(context)
            if (!repo.remindersOn) return
            ensureChannel(context)
            val nmc = NotificationManagerCompat.from(context)
            if (!nmc.areNotificationsEnabled()) return

            val today = LocalDate.now()
            val remindDays = repo.remindDays
            val sent = repo.notified.toMutableSet()
            var changed = false

            val intent = Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            for (s in repo.load()) {
                val next = s.nextCharge(today)
                val days = s.daysUntilNext(today)
                val trial = s.isInTrial(today)
                val fire = days == remindDays || days == 0 || (trial && days == 1)
                if (!fire) continue
                val key = "${s.id}_${next.toEpochDay()}_$days"
                if (key in sent) continue

                val price = formatMoney(s.price, s.currency)
                val title: String
                val text: String
                when {
                    trial && days == 0 -> {
                        title = "Ma lejár: ${s.name} próbaidő"
                        text = "Ma levonják az első díjat ($price). Ha nem kéred, most mondd le."
                    }
                    trial -> {
                        title = "${s.name}: ${dueText(days).lowercase()} lejár a próbaidő"
                        text = "Utána $price lesz. Ha nem kéred, még időben lemondhatod."
                    }
                    days == 0 -> {
                        title = "Ma vonják le: ${s.name}"
                        text = "$price · ${s.cycle.label.lowercase()}"
                    }
                    else -> {
                        title = "${s.name}: $price ${dueText(days).lowercase()}"
                        text = "Terhelés: ${formatDate(next, today)}. Ha nem használod, még lemondhatod."
                    }
                }

                val n = NotificationCompat.Builder(context, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
                try {
                    nmc.notify(s.id.hashCode(), n)
                    sent += key
                    changed = true
                } catch (e: SecurityException) {
                    return
                }
            }
            if (changed) repo.notified = sent.toList().takeLast(300).toSet()
        }
    }
}
