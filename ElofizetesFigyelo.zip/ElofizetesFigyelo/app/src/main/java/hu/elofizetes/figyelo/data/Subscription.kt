package hu.elofizetes.figyelo.data

import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class Cycle(val label: String, val short: String, val months: Double) {
    WEEKLY("Hetente", "Heti", 12.0 / 52.0),
    MONTHLY("Havonta", "Havi", 1.0),
    QUARTERLY("Negyedévente", "Negyedévi", 3.0),
    YEARLY("Évente", "Éves", 12.0);

    fun add(date: LocalDate, n: Long): LocalDate = when (this) {
        WEEKLY -> date.plusWeeks(n)
        MONTHLY -> date.plusMonths(n)
        QUARTERLY -> date.plusMonths(3 * n)
        YEARLY -> date.plusYears(n)
    }
}

enum class Category(val label: String) {
    STREAMING("Film, sorozat"),
    MUSIC("Zene"),
    SOFTWARE("Szoftver"),
    CLOUD("Tárhely"),
    NEWS("Hírek, olvasás"),
    GAMES("Játék"),
    FITNESS("Sport"),
    UTILITIES("Telefon, net"),
    OTHER("Egyéb"),
}

/**
 * Egy előfizetés. A [firstCharge] egy ismert terhelési nap (vagy a próbaidő vége),
 * innen számoljuk előre a többit, így a hónap végi napok sem csúsznak el.
 */
data class Subscription(
    val id: String,
    val name: String,
    val price: Double,
    val currency: String,
    val cycle: Cycle,
    val firstCharge: LocalDate,
    val category: Category,
    val colorIndex: Int,
    val trial: Boolean,
    val note: String,
) {
    val monthlyCost: Double get() = price / cycle.months

    fun nextCharge(today: LocalDate): LocalDate {
        if (!firstCharge.isBefore(today)) return firstCharge
        var k = 1L
        var d = cycle.add(firstCharge, k)
        while (d.isBefore(today)) {
            k++
            d = cycle.add(firstCharge, k)
        }
        return d
    }

    /** Próbaidőben van-e még (a próbaidő végét is beleértve). */
    fun isInTrial(today: LocalDate): Boolean = trial && !today.isAfter(firstCharge)

    fun daysUntilNext(today: LocalDate): Int =
        ChronoUnit.DAYS.between(today, nextCharge(today)).toInt()

    /** Hány terhelés esik a mai naptól [end]-ig (mindkettőt beleértve). */
    fun chargesUntil(today: LocalDate, end: LocalDate): Int {
        var d = nextCharge(today)
        var count = 0
        while (!d.isAfter(end)) {
            count++
            d = cycle.add(d, 1)
        }
        return count
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("price", price)
        .put("currency", currency)
        .put("cycle", cycle.name)
        .put("first", firstCharge.toString())
        .put("category", category.name)
        .put("color", colorIndex)
        .put("trial", trial)
        .put("note", note)

    companion object {
        fun fromJson(o: JSONObject): Subscription? = try {
            Subscription(
                id = o.getString("id"),
                name = o.getString("name"),
                price = o.getDouble("price"),
                currency = o.optString("currency", "HUF"),
                cycle = runCatching { Cycle.valueOf(o.getString("cycle")) }.getOrDefault(Cycle.MONTHLY),
                firstCharge = LocalDate.parse(o.getString("first")),
                category = runCatching { Category.valueOf(o.getString("category")) }.getOrDefault(Category.OTHER),
                colorIndex = o.optInt("color", 0),
                trial = o.optBoolean("trial", false),
                note = o.optString("note", ""),
            )
        } catch (e: Exception) {
            null
        }
    }
}

/** Gyakori szolgáltatások gyors kiválasztáshoz (gépelés helyett). */
data class Preset(val name: String, val category: Category, val colorIndex: Int)

val Presets = listOf(
    Preset("Netflix", Category.STREAMING, 2),
    Preset("Spotify", Category.MUSIC, 4),
    Preset("YouTube Premium", Category.STREAMING, 2),
    Preset("Disney+", Category.STREAMING, 1),
    Preset("HBO Max", Category.STREAMING, 8),
    Preset("SkyShowtime", Category.STREAMING, 7),
    Preset("Apple iCloud+", Category.CLOUD, 1),
    Preset("Google One", Category.CLOUD, 1),
    Preset("ChatGPT Plus", Category.SOFTWARE, 5),
    Preset("Microsoft 365", Category.SOFTWARE, 3),
    Preset("Amazon Prime", Category.STREAMING, 0),
    Preset("Xbox Game Pass", Category.GAMES, 4),
    Preset("PlayStation Plus", Category.GAMES, 1),
    Preset("Edzőterem", Category.FITNESS, 3),
)
