package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.elofizetes.figyelo.SubsViewModel
import hu.elofizetes.figyelo.data.Subscription
import hu.elofizetes.figyelo.data.formatMoney
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun OverviewScreen(vm: SubsViewModel) {
    val c = LocalAppColors.current
    val today = LocalDate.now()
    val monthEnd = today.withDayOfMonth(today.lengthOfMonth())
    val byCurrency = vm.subs.groupBy { it.currency }.toList().sortedByDescending { it.second.size }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item(key = "header") {
            LargeTitleHeader(
                title = "Áttekintés",
                subtitle = if (vm.subs.isEmpty()) null else "${vm.subs.size} előfizetés",
            )
        }

        if (vm.subs.isEmpty()) {
            item(key = "empty") {
                Text(
                    "Ha felveszel előfizetéseket, itt látod, mennyit költesz rájuk havonta és évente.",
                    fontSize = 15.sp,
                    color = c.secondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                )
            }
            return@LazyColumn
        }

        byCurrency.forEach { (cur, list) ->
            val sorted = list.sortedByDescending { it.monthlyCost }
            val monthly = list.sumOf { it.monthlyCost }
            val leftThisMonth = list.sumOf { it.chargesUntil(today, monthEnd) * it.price }

            item(key = "h_$cur") {
                SectionHeader(if (byCurrency.size > 1) "Költés · $cur" else "Költés")
            }
            item(key = "c_$cur") {
                GroupCard {
                    Row(Modifier.fillMaxWidth().padding(16.dp)) {
                        Stat("Havonta", formatMoney(monthly, cur), Modifier.weight(1f))
                        Stat("Évente", formatMoney(monthly * 12, cur), Modifier.weight(1f))
                    }
                    if (monthly > 0) {
                        StackedBar(sorted, monthly, Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp))
                    }
                    InsetDivider()
                    sorted.forEachIndexed { i, s ->
                        ShareRow(s, monthly, cur)
                        if (i < sorted.lastIndex) InsetDivider(start = 42.dp)
                    }
                }
            }
            item(key = "f_$cur") {
                SectionFooter(
                    if (leftThisMonth > 0) "Ebben a hónapban még ${formatMoney(leftThisMonth, cur)} terhelés várható."
                    else "Ebben a hónapban már nem várható több terhelés."
                )
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    val c = LocalAppColors.current
    Column(modifier) {
        Text(label, fontSize = 13.sp, color = c.secondary)
        Spacer(Modifier.height(2.dp))
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = c.label, maxLines = 1)
    }
}

/** Arányos sáv; csak kiegészítés, a lenti sorok szövegesen is megadják ugyanezt. */
@Composable
private fun StackedBar(items: List<Subscription>, total: Double, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .clearAndSetSemantics { },
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items.filter { it.monthlyCost > 0 }.forEach { s ->
            Box(
                Modifier
                    .weight((s.monthlyCost / total).toFloat().coerceAtLeast(0.01f))
                    .fillMaxHeight()
                    .background(paletteColor(s.colorIndex)),
            )
        }
    }
}

@Composable
private fun ShareRow(s: Subscription, total: Double, cur: String) {
    val c = LocalAppColors.current
    val pct = if (total > 0) (s.monthlyCost / total * 100).roundToInt() else 0
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(paletteColor(s.colorIndex)))
        Spacer(Modifier.width(14.dp))
        Text(
            s.name,
            fontSize = 17.sp,
            color = c.label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text("${formatMoney(s.monthlyCost, cur)}/hó", fontSize = 15.sp, color = c.label)
            Text("$pct%", fontSize = 13.sp, color = c.secondary)
        }
    }
}
