package hu.elofizetes.figyelo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import hu.elofizetes.figyelo.data.Repository
import hu.elofizetes.figyelo.data.Subscription

class SubsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)

    val subs = mutableStateListOf<Subscription>().apply { addAll(repo.load()) }

    var remindersOn by mutableStateOf(repo.remindersOn)
        private set
    var remindDays by mutableStateOf(repo.remindDays)
        private set
    var promptDismissed by mutableStateOf(repo.promptDismissed)
        private set

    private fun persist() {
        repo.save(subs.toList())
        if (remindersOn) ReminderWorker.checkNow(getApplication())
    }

    fun upsert(s: Subscription) {
        val i = subs.indexOfFirst { it.id == s.id }
        if (i >= 0) subs[i] = s else subs.add(s)
        persist()
    }

    fun addAll(list: List<Subscription>) {
        if (list.isEmpty()) return
        subs.addAll(list)
        persist()
    }

    /** Törli, és visszaadja a helyét a visszavonáshoz. */
    fun delete(s: Subscription): Int {
        val i = subs.indexOfFirst { it.id == s.id }
        if (i >= 0) subs.removeAt(i)
        persist()
        return i
    }

    fun restore(s: Subscription, index: Int) {
        if (subs.any { it.id == s.id }) return
        subs.add(index.coerceIn(0, subs.size), s)
        persist()
    }

    fun setReminders(on: Boolean) {
        remindersOn = on
        repo.remindersOn = on
        if (on) {
            repo.promptDismissed = true
            promptDismissed = true
            ReminderWorker.schedule(getApplication(), replace = true)
        } else {
            ReminderWorker.cancel(getApplication())
        }
    }

    fun updateRemindDays(days: Int) {
        remindDays = days
        repo.remindDays = days
        if (remindersOn) ReminderWorker.checkNow(getApplication())
    }

    fun dismissPrompt() {
        promptDismissed = true
        repo.promptDismissed = true
    }
}
