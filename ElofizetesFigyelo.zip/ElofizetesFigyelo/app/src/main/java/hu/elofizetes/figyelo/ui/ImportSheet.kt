package hu.elofizetes.figyelo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.elofizetes.figyelo.data.ImportCandidate
import hu.elofizetes.figyelo.data.ImportResult
import hu.elofizetes.figyelo.data.formatDate
import hu.elofizetes.figyelo.data.formatMoney
import kotlinx.coroutines.launch

/** Tipp, hogyan lehet CSV-t exportálni a banki appokból. */
const val EXPORT_TIP =
    "A bankod appjában vagy netbankjában nyisd meg a számlatörténetet, válaszd az Exportálás / " +
        "Letöltés lehetőséget, CSV formátumot és legalább az elmúlt 3–6 hónapot."

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportSheet(
    result: ImportResult,
    existingNames: Set<String>,
    onDismiss: () -> Unit,
    onPickAnother: () -> Unit,
    onAdd: (List<ImportCandidate>) -> Unit,
) {
    val c = LocalAppColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val items = result.candidates
    fun exists(i: ImportCandidate) = i.name.lowercase() in existingNames
    val selected = remember(result) {
        mutableStateListOf<Int>().apply {
            items.forEachIndexed { i, it -> if (it.confident && !exists(it)) add(i) }
        }
    }

    fun close(after: () -> Unit) {
        scope.launch { sheetState.hide() }.invokeOnCompletion { after() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.groupedBg,
        dragHandle = { BottomSheetDefaults.DragHandle(color = c.separator) },
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp)) {
                TextButton(onClick = { close(onDismiss) }, modifier = Modifier.align(Alignment.CenterStart)) {
                    Text("Mégse", fontSize = 17.sp, color = c.accent)
                }
                Text(
                    "Bankkivonat",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.label,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                if (items.isEmpty()) {
                    NothingFound(result, onPickAnother = { close(onPickAnother) })
                    return@Column
                }

                Text(
                    "${result.transactions} tételből ${items.size} ismétlődő terhelést találtam. " +
                        "Jelöld ki, amit felveszel.",
                    fontSize = 15.sp,
                    color = c.secondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )

                GroupCard {
                    items.forEachIndexed { i, cand ->
                        CandidateRow(
                            cand = cand,
                            checked = i in selected,
                            alreadyAdded = exists(cand),
                            onToggle = { on -> if (on) selected.add(i) else selected.remove(i) },
                        )
                        if (i < items.lastIndex) InsetDivider(start = 112.dp)
                    }
                }
                SectionFooter("A fájlt csak a telefonodon olvassuk be, nem küldjük el sehova.")

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        val picked = selected.sorted().map { items[it] }
                        close { onAdd(picked) }
                    },
                    enabled = selected.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = c.accentFill,
                        contentColor = Color.White,
                        disabledContainerColor = c.fill,
                        disabledContentColor = c.secondary,
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(min = 50.dp),
                ) {
                    Text(
                        if (selected.isEmpty()) "Jelölj ki legalább egyet"
                        else "${selected.size} előfizetés hozzáadása",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun CandidateRow(
    cand: ImportCandidate,
    checked: Boolean,
    alreadyAdded: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    val c = LocalAppColors.current
    val detail = buildString {
        append(cand.cycle.label)
        append(" · utoljára ")
        append(formatDate(cand.lastCharge))
        append(" · ")
        append(cand.count)
        append(" terhelés")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                enabled = !alreadyAdded,
                role = Role.Checkbox,
                onValueChange = onToggle,
            )
            .heightIn(min = 64.dp)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CheckCircle(checked = checked, enabled = !alreadyAdded)
        Spacer(Modifier.width(14.dp))
        LetterTile(cand.name, cand.colorIndex)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(cand.name, fontSize = 17.sp, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, fontSize = 13.sp, color = c.secondary, maxLines = 2)
            val note = if (alreadyAdded) "Már szerepel a listádban" else cand.hint
            if (note != null) {
                Text(note, fontSize = 13.sp, color = if (alreadyAdded) c.secondary else c.danger)
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            formatMoney(cand.price, cand.currency),
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = c.label,
        )
    }
}

@Composable
private fun CheckCircle(checked: Boolean, enabled: Boolean) {
    val c = LocalAppColors.current
    val shape = CircleShape
    Box(
        Modifier
            .size(24.dp)
            .clip(shape)
            .then(
                if (checked) Modifier.background(c.accentFill)
                else Modifier.border(1.5.dp, if (enabled) c.secondary else c.separator, shape)
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun NothingFound(result: ImportResult, onPickAnother: () -> Unit) {
    val c = LocalAppColors.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(c.accent.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.SearchOff, contentDescription = null, tint = c.accent, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (result.error != null) "Ezt a fájlt nem tudom beolvasni" else "Nem találtam ismétlődő terhelést",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.label,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            result.error
                ?: "${result.transactions} tételt néztem át. Próbálj hosszabb időszakot exportálni, legalább 3 hónapot.",
            fontSize = 15.sp,
            color = c.secondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(EXPORT_TIP, fontSize = 13.sp, color = c.secondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onPickAnother,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.accentFill, contentColor = Color.White),
            modifier = Modifier.heightIn(min = 50.dp),
        ) {
            Text("Másik fájl választása", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
