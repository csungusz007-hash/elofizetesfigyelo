package hu.elofizetes.figyelo.data

import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Currency
import java.util.Locale

private val HU = Locale("hu", "HU")
private val shortDate = DateTimeFormatter.ofPattern("MMM d.", HU)
private val shortDateYear = DateTimeFormatter.ofPattern("yyyy. MMM d.", HU)
private val longDate = DateTimeFormatter.ofPattern("yyyy. MMMM d.", HU)

val Currencies = listOf("HUF", "EUR", "USD")

fun formatMoney(amount: Double, currency: String): String {
    val nf = NumberFormat.getCurrencyInstance(HU)
    runCatching { nf.currency = Currency.getInstance(currency) }
    val frac = if (currency == "HUF") 0 else 2
    nf.minimumFractionDigits = frac
    nf.maximumFractionDigits = frac
    return nf.format(amount)
}

fun currencySymbol(currency: String): String = when (currency) {
    "HUF" -> "Ft"
    "EUR" -> "€"
    "USD" -> "$"
    else -> currency
}

/** Szerkesztéshez: 4990 vagy 12,99 */
fun formatPlain(price: Double): String =
    if (price % 1.0 == 0.0) price.toLong().toString() else price.toString().replace('.', ',')

fun parsePrice(text: String): Double? =
    text.replace(" ", "").replace(' '.toString(), "").replace(',', '.').toDoubleOrNull()

fun formatDate(d: LocalDate, today: LocalDate = LocalDate.now()): String =
    if (d.year == today.year) shortDate.format(d) else shortDateYear.format(d)

fun formatDateLong(d: LocalDate): String = longDate.format(d)

fun dueText(days: Int): String = when {
    days <= 0 -> "Ma"
    days == 1 -> "Holnap"
    else -> "$days nap múlva"
}

/** Pl. „12 480 Ft” vagy több pénznemnél „12 480 Ft + 9,99 €”. */
fun totalsText(subs: List<Subscription>, months: Double): String =
    subs.groupBy { it.currency }
        .map { (cur, list) -> formatMoney(list.sumOf { it.monthlyCost } * months, cur) }
        .joinToString(" + ")
