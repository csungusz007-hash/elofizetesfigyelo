package hu.elofizetes.figyelo.data

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import java.util.concurrent.TimeUnit

/**
 * A Gmail-kapcsolat állapota. Jelszót nem tárolunk: a hozzáférést a Google
 * engedélyablaka adja, és a Google-fiókodban bármikor visszavonhatod.
 */
class GmailAccount(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("gmail", Context.MODE_PRIVATE)

    val email: String? get() = prefs.getString("email", null)
    val isConnected: Boolean get() = prefs.getBoolean("connected", false)

    var lastScan: Long
        get() = prefs.getLong("last_scan", 0L)
        set(v) = prefs.edit().putLong("last_scan", v).apply()

    fun markConnected(email: String?) {
        prefs.edit()
            .putBoolean("connected", true)
            .putString("email", email)
            .putLong("last_scan", System.currentTimeMillis())
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    companion object {
        fun request(): AuthorizationRequest =
            AuthorizationRequest.builder()
                .setRequestedScopes(listOf(Scope(GmailApi.SCOPE)))
                .build()

        /** Háttérben: token, ha nem kell hozzá a felhasználó; különben null. */
        fun tokenSilently(context: Context): String? = try {
            val result = Tasks.await(
                Identity.getAuthorizationClient(context).authorize(request()), 30, TimeUnit.SECONDS
            )
            if (result.hasResolution()) null else result.accessToken
        } catch (e: Exception) {
            null
        }
    }
}
