package hu.elofizetes.figyelo

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.identity.Identity
import hu.elofizetes.figyelo.data.GmailAccount
import hu.elofizetes.figyelo.data.GmailApi
import hu.elofizetes.figyelo.data.ImportCandidate
import hu.elofizetes.figyelo.data.ImportResult
import hu.elofizetes.figyelo.data.MailClassifier
import hu.elofizetes.figyelo.data.StatementImporter
import hu.elofizetes.figyelo.data.Subscription
import hu.elofizetes.figyelo.ui.AppTab
import hu.elofizetes.figyelo.ui.AppTheme
import hu.elofizetes.figyelo.ui.EditSheet
import hu.elofizetes.figyelo.ui.GmailSheet
import hu.elofizetes.figyelo.ui.ImportSheet
import hu.elofizetes.figyelo.ui.ImportSource
import hu.elofizetes.figyelo.ui.ListScreen
import hu.elofizetes.figyelo.ui.LocalAppColors
import hu.elofizetes.figyelo.ui.OverviewScreen
import hu.elofizetes.figyelo.ui.SettingsScreen
import hu.elofizetes.figyelo.ui.TabBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val openGmail = intent?.getBooleanExtra(EXTRA_SCAN_GMAIL, false) == true
        setContent {
            AppTheme { App(openGmailScan = openGmail) }
        }
    }

    companion object {
        const val EXTRA_SCAN_GMAIL = "scan_gmail"
    }
}

@Composable
fun App(vm: SubsViewModel = viewModel(), openGmailScan: Boolean = false) {
    val c = LocalAppColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(AppTab.SUBS) }
    var sheetOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Subscription?>(null) }

    // Az értesítési engedélyt csak akkor kérjük, amikor a felhasználó bekapcsolja.
    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> vm.setReminders(granted) }

    val enableReminders: () -> Unit = {
        val needsAsk = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsAsk) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else vm.setReminders(true)
    }

    // Bankkivonat beolvasása: a fájl csak a telefonon kerül feldolgozásra.
    var importResult by remember { mutableStateOf<ImportResult?>(null) }
    var importSource by remember { mutableStateOf(ImportSource.BANK) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            importResult = withContext(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                        val buf = input.readBytes()
                        if (buf.size > 20 * 1024 * 1024) null else buf
                    }
                    importSource = ImportSource.BANK
                    if (bytes == null) ImportResult(0, emptyList(), "A fájl túl nagy vagy nem nyitható meg.")
                    else StatementImporter.analyze(bytes)
                } catch (e: Exception) {
                    ImportResult(0, emptyList(), "Nem sikerült megnyitni a fájlt.")
                }
            }
        }
    }
    val startImport: () -> Unit = {
        picker.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel", "application/octet-stream", "*/*"))
    }

    // Gmail: a Google engedélyablakával (csak olvasás), feldolgozás a telefonon.
    val account = remember { GmailAccount(context.applicationContext) }
    var gmailEmail by remember { mutableStateOf(if (account.isConnected) account.email ?: "Gmail" else null) }
    var gmailOpen by remember { mutableStateOf(false) }
    var gmailBusy by remember { mutableStateOf<String?>(null) }
    var gmailError by remember { mutableStateOf<String?>(null) }

    fun runGmailScan(token: String) {
        gmailError = null
        gmailBusy = "Levelek keresése…"
        scope.launch {
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val today = LocalDate.now()
                    val email = GmailApi.profileEmail(token)
                    val (mails, _) = GmailApi.fetchMails(token, today.minusMonths(13)) { i, n ->
                        gmailBusy = "Levelek átnézése: $i / $n"
                    }
                    Result.success(email to ImportResult(mails.size, MailClassifier.detect(mails, today)))
                } catch (e: GmailApi.GmailError) {
                    Result.failure(e)
                } catch (e: Exception) {
                    Result.failure(Exception("Váratlan hiba történt a levelek olvasásakor. Próbáld újra."))
                }
            }
            gmailBusy = null
            outcome.onSuccess { (email, res) ->
                account.markConnected(email)
                gmailEmail = email ?: "Gmail"
                gmailOpen = false
                importSource = ImportSource.GMAIL
                importResult = res
            }.onFailure { gmailError = it.message }
        }
    }

    val consent = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res ->
        val token = if (res.resultCode == Activity.RESULT_OK) {
            runCatching {
                Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(res.data).accessToken
            }.getOrNull()
        } else null
        if (token != null) runGmailScan(token) else {
            gmailBusy = null
            gmailError = "Nem kaptam engedélyt a Gmailhez. Próbáld újra, és a Google ablakában engedélyezd a hozzáférést."
        }
    }

    val requestGmail: () -> Unit = {
        gmailError = null
        gmailBusy = "Engedély kérése a Google-től…"
        Identity.getAuthorizationClient(context)
            .authorize(GmailAccount.request())
            .addOnSuccessListener { result ->
                val pending = result.pendingIntent
                val token = result.accessToken
                when {
                    result.hasResolution() && pending != null ->
                        consent.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                    token != null -> runGmailScan(token)
                    else -> {
                        gmailBusy = null
                        gmailError = "Nem kaptam engedélyt a Gmailhez. Próbáld újra."
                    }
                }
            }
            .addOnFailureListener { e ->
                gmailBusy = null
                gmailError = "A Google nem adott hozzáférést. Ellenőrizd az internetkapcsolatot, és próbáld újra." +
                    (e.message?.let { " ($it)" } ?: "")
            }
    }

    // Ha már engedélyezted, rögtön indul; különben előbb elmagyarázzuk, mi fog történni.
    val startGmail: () -> Unit = {
        gmailError = null
        gmailOpen = true
        if (account.isConnected) requestGmail()
    }
    val disconnectGmail: () -> Unit = {
        account.clear()
        gmailEmail = null
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar("Gmail leválasztva. A hozzáférést a Google-fiókodban is visszavonhatod.")
        }
    }

    LaunchedEffect(Unit) {
        if (vm.remindersOn) ReminderWorker.schedule(context, replace = false)
        if (openGmailScan) startGmail()
    }

    Scaffold(
        containerColor = c.groupedBg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { TabBar(current = tab, onSelect = { tab = it }) },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                AppTab.SUBS -> ListScreen(
                    vm = vm,
                    onAdd = { editing = null; sheetOpen = true },
                    onOpen = { editing = it; sheetOpen = true },
                    onEnableReminders = enableReminders,
                    onImport = startImport,
                    onGmail = startGmail,
                )
                AppTab.OVERVIEW -> OverviewScreen(vm = vm)
                AppTab.SETTINGS -> SettingsScreen(
                    vm = vm,
                    onEnableReminders = enableReminders,
                    onImport = startImport,
                    gmailEmail = gmailEmail,
                    onGmail = startGmail,
                    onGmailDisconnect = disconnectGmail,
                )
            }
        }
    }

    if (sheetOpen) {
        EditSheet(
            initial = editing,
            onDismiss = { sheetOpen = false },
            onSave = { vm.upsert(it); sheetOpen = false },
            onDelete = { s ->
                sheetOpen = false
                val index = vm.delete(s)
                scope.launch {
                    snackbar.currentSnackbarData?.dismiss()
                    val r = snackbar.showSnackbar(
                        message = "${s.name} törölve",
                        actionLabel = "Visszavonás",
                        duration = SnackbarDuration.Long,
                    )
                    if (r == SnackbarResult.ActionPerformed) vm.restore(s, index)
                }
            },
        )
    }

    if (gmailOpen) {
        GmailSheet(
            busy = gmailBusy,
            error = gmailError,
            onAllow = requestGmail,
            onDismiss = { gmailOpen = false },
        )
    }

    importResult?.let { result ->
        ImportSheet(
            result = result,
            existingNames = vm.subs.map { it.name.lowercase() }.toSet(),
            source = importSource,
            onDismiss = { importResult = null },
            onPickAnother = {
                importResult = null
                if (importSource == ImportSource.BANK) startImport() else startGmail()
            },
            onAdd = { picked ->
                importResult = null
                val note = if (importSource == ImportSource.GMAIL) "Gmailből" else "Bankkivonatból"
                vm.addAll(picked.map { it.toSubscription(note) })
                scope.launch {
                    snackbar.currentSnackbarData?.dismiss()
                    snackbar.showSnackbar("${picked.size} előfizetés hozzáadva")
                }
                tab = AppTab.SUBS
            },
        )
    }
}

private fun ImportCandidate.toSubscription(note: String) = Subscription(
    id = UUID.randomUUID().toString(),
    name = name,
    price = price,
    currency = currency,
    cycle = cycle,
    firstCharge = nextCharge,
    category = category,
    colorIndex = colorIndex,
    trial = trial,
    note = note,
)
