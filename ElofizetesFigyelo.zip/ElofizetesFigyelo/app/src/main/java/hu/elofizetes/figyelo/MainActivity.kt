package hu.elofizetes.figyelo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import hu.elofizetes.figyelo.data.ImportCandidate
import hu.elofizetes.figyelo.data.ImportResult
import hu.elofizetes.figyelo.data.StatementImporter
import hu.elofizetes.figyelo.data.Subscription
import hu.elofizetes.figyelo.ui.AppTab
import hu.elofizetes.figyelo.ui.AppTheme
import hu.elofizetes.figyelo.ui.EditSheet
import hu.elofizetes.figyelo.ui.ImportSheet
import hu.elofizetes.figyelo.ui.ListScreen
import hu.elofizetes.figyelo.ui.LocalAppColors
import hu.elofizetes.figyelo.ui.OverviewScreen
import hu.elofizetes.figyelo.ui.SettingsScreen
import hu.elofizetes.figyelo.ui.TabBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme { App() }
        }
    }
}

@Composable
fun App(vm: SubsViewModel = viewModel()) {
    val c = LocalAppColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(AppTab.SUBS) }
    var sheetOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Subscription?>(null) }

    // Az értesítési engedélyt csak akkor kérjük, amikor a felhasználó bekapcsolja.
    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> vm.setReminders(granted) }

    val enableReminders: () -> Unit = {
        val needsAsk = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsAsk) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else vm.setReminders(true)
    }

    // Bankkivonat beolvasása: a fájl csak a telefonon kerül feldolgozásra.
    var importResult by remember { mutableStateOf<ImportResult?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            importResult = withContext(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                        val buf = input.readBytes()
                        if (buf.size > 20 * 1024 * 1024) null else buf
                    }
                    if (bytes == null) ImportResult(0, emptyList(), "A fájl túl nagy vagy nem nyitható meg.")
                    else StatementImporter.analyze(bytes)
                } catch (e: Exception) {
                    ImportResult(0, emptyList(), "Nem sikerült megnyitni a fájlt.")
                }
            }
        }
    }
    val startImport: () -> Unit = {
        picker.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel", "application/octet-stream", "*/*"))
    }

    LaunchedEffect(Unit) {
        if (vm.remindersOn) ReminderWorker.schedule(context, replace = false)
    }

    Scaffold(
        containerColor = c.groupedBg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { TabBar(current = tab, onSelect = { tab = it }) },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                AppTab.SUBS -> ListScreen(
                    vm = vm,
                    onAdd = { editing = null; sheetOpen = true },
                    onOpen = { editing = it; sheetOpen = true },
                    onEnableReminders = enableReminders,
                    onImport = startImport,
                )
                AppTab.OVERVIEW -> OverviewScreen(vm = vm)
                AppTab.SETTINGS -> SettingsScreen(vm = vm, onEnableReminders = enableReminders, onImport = startImport)
            }
        }
    }

    if (sheetOpen) {
        EditSheet(
            initial = editing,
            onDismiss = { sheetOpen = false },
            onSave = { vm.upsert(it); sheetOpen = false },
            onDelete = { s ->
                sheetOpen = false
                val index = vm.delete(s)
                scope.launch {
                    snackbar.currentSnackbarData?.dismiss()
                    val r = snackbar.showSnackbar(
                        message = "${s.name} törölve",
                        actionLabel = "Visszavonás",
                        duration = SnackbarDuration.Long,
                    )
                    if (r == SnackbarResult.ActionPerformed) vm.restore(s, index)
                }
            },
        )
    }

    importResult?.let { result ->
        ImportSheet(
            result = result,
            existingNames = vm.subs.map { it.name.lowercase() }.toSet(),
            onDismiss = { importResult = null },
            onPickAnother = { importResult = null; startImport() },
            onAdd = { picked ->
                importResult = null
                vm.addAll(picked.map { it.toSubscription() })
                scope.launch {
                    snackbar.currentSnackbarData?.dismiss()
                    snackbar.showSnackbar("${picked.size} előfizetés hozzáadva")
                }
                tab = AppTab.SUBS
            },
        )
    }
}

private fun ImportCandidate.toSubscription() = Subscription(
    id = UUID.randomUUID().toString(),
    name = name,
    price = price,
    currency = currency,
    cycle = cycle,
    firstCharge = nextCharge,
    category = category,
    colorIndex = colorIndex,
    trial = false,
    note = "Bankkivonatból",
)
