package hu.elofizetes.figyelo.data

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.text.Normalizer
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** Egy banki tétel; az [amount] pozitív szám = terhelés (kiadás). */
data class Transaction(
    val date: LocalDate,
    val amount: Double,
    val currency: String,
    val description: String,
)

data class ImportCandidate(
    val name: String,
    val price: Double,
    val currency: String,
    val cycle: Cycle,
    val lastCharge: LocalDate,
    val nextCharge: LocalDate,
    val count: Int,
    val category: Category,
    val colorIndex: Int,
    /** Biztos találat: rendszeres időköz és hasonló összeg. */
    val confident: Boolean,
    val hint: String?,
    /** Próbaidő: ilyenkor a [nextCharge] a próbaidő vége. */
    val trial: Boolean = false,
) {
    val monthlyCost: Double get() = price / cycle.months
}

data class ImportResult(
    val transactions: Int,
    val candidates: List<ImportCandidate>,
    val error: String? = null,
)

/**
 * Bankszámlakivonat (CSV) beolvasása és az ismétlődő terhelések felismerése.
 * Minden a telefonon történik, hálózat nélkül.
 */
object StatementImporter {

    // ---------- Belépési pont ----------

    fun analyze(bytes: ByteArray, today: LocalDate = LocalDate.now()): ImportResult {
        if (bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
            return ImportResult(0, emptyList(),
                "Ez Excel-fájl (.xlsx). A bankod appjában CSV formátumban exportáld a számlatörténetet.")
        }
        if (bytes.size >= 4 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "%PDF") {
            return ImportResult(0, emptyList(),
                "Ez PDF-kivonat. A bankod appjában CSV formátumban exportáld a számlatörténetet.")
        }
        val tx = parseTransactions(decode(bytes))
        if (tx.isEmpty()) {
            return ImportResult(0, emptyList(),
                "Nem találtam tranzakciókat a fájlban. Számlatörténetet válassz CSV formátumban.")
        }
        return ImportResult(tx.size, detect(tx, today))
    }

    // ---------- Szöveg és CSV ----------

    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if ((b0 == 0xFF && b1 == 0xFE) || (b0 == 0xFE && b1 == 0xFF)) return String(bytes, Charsets.UTF_16)
        }
        var b = bytes
        if (b.size >= 3 && (b[0].toInt() and 0xFF) == 0xEF && (b[1].toInt() and 0xFF) == 0xBB && (b[2].toInt() and 0xFF) == 0xBF) {
            b = b.copyOfRange(3, b.size)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            // A magyar bankok gyakran Windows-1250 kódolással exportálnak.
            String(b, Charset.forName("windows-1250"))
        }
    }

    private fun detectDelimiter(lines: List<String>): Char {
        val candidates = listOf(';', ',', '\t', '|')
        return candidates.maxByOrNull { d ->
            val counts = lines.map { l -> splitCsv(l, d).size - 1 }.filter { it > 0 }
            if (counts.isEmpty()) 0.0 else {
                val mode = counts.groupingBy { it }.eachCount().maxByOrNull { it.value }!!
                mode.value * 10.0 + mode.key
            }
        } ?: ';'
    }

    fun splitCsv(line: String, d: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && inQ && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> inQ = !inQ
                ch == d && !inQ -> { out.add(sb.toString().trim()); sb.setLength(0) }
                else -> sb.append(ch)
            }
            i++
        }
        out.add(sb.toString().trim())
        return out
    }

    internal fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

    // ---------- Oszlopok ----------

    private data class Columns(
        val date: Int,
        val amount: Int?,
        val debit: Int?,
        val currency: Int?,
        val type: Int?,
        val desc: List<Int>,
    )

    private fun isDateHeader(h: String) =
        listOf("datum", "date", "konyveles", "teljesites", "erteknap").any { it in h }

    private fun isBalanceHeader(h: String) =
        listOf("egyenleg", "balance", "fee", "jutalek", "azonosito", "szamlaszam", "id").any { h == it || it in h && it.length > 2 }

    private fun isAmountHeader(h: String) =
        !isDateHeader(h) && !isBalanceHeader(h) && listOf("osszeg", "amount", "ertek", "value").any { it in h }

    private fun isDebitHeader(h: String) =
        !isDateHeader(h) && listOf("terheles", "debit", "kiadas", "jovairas nelkul").any { it in h }

    private fun isCurrencyHeader(h: String) =
        !isAmountHeader(h) && listOf("deviza", "penznem", "currency", "valuta").any { it in h }

    private fun isTypeHeader(h: String) =
        listOf("jelleg", "irany", "t/j", "terheles/jovairas").any { it in h }

    private fun isDescHeader(h: String) =
        !isDateHeader(h) && !isAmountHeader(h) && !isCurrencyHeader(h) && !isBalanceHeader(h) &&
            listOf(
                "kozlemeny", "leiras", "description", "partner", "kedvezmenyezett", "megnevezes",
                "merchant", "ellenoldal", "nev", "reference", "referencia", "szoveg", "megjegyzes",
                "payee", "counterparty", "details", "kereskedo", "elfogado", "tranzakcio",
            ).any { it in h } && !listOf("tipus", "type", "azonosito").any { it in h }

    private fun columnsFromHeader(h: List<String>): Columns? {
        val dateIdx = h.indexOfFirst { isDateHeader(it) && ("konyvel" in it || "completed" in it || "teljesit" in it) }
            .takeIf { it >= 0 } ?: h.indexOfFirst { isDateHeader(it) }
        if (dateIdx < 0) return null
        val amountIdx = h.indexOfFirst { isAmountHeader(it) && "eredeti" !in it && "original" !in it }
            .takeIf { it >= 0 } ?: h.indexOfFirst { isAmountHeader(it) }
        val debitIdx = h.indexOfFirst { isDebitHeader(it) && !isTypeHeader(it) }
        val curIdx = h.indexOfFirst { isCurrencyHeader(it) }
        val typeIdx = h.indexOfFirst { isTypeHeader(it) }
        val desc = h.indices.filter { isDescHeader(h[it]) }
        if (amountIdx < 0 && debitIdx < 0) return null
        return Columns(
            date = dateIdx,
            amount = amountIdx.takeIf { it >= 0 },
            debit = debitIdx.takeIf { it >= 0 && amountIdx < 0 },
            currency = curIdx.takeIf { it >= 0 },
            type = typeIdx.takeIf { it >= 0 },
            desc = desc.ifEmpty { h.indices.filter { it != dateIdx && it != amountIdx && it != curIdx } },
        )
    }

    /** Fejléc nélküli fájl: a tartalom alapján találjuk ki az oszlopokat. */
    private fun inferColumns(rows: List<List<String>>): Columns? {
        val sample = rows.take(200)
        val width = sample.maxOfOrNull { it.size } ?: return null
        val dateScore = IntArray(width)
        val numScore = IntArray(width)
        val negScore = IntArray(width)
        val textLen = DoubleArray(width)
        for (r in sample) for (i in r.indices) {
            val c = r[i]
            if (parseDate(c) != null) dateScore[i]++
            else {
                val v = parseAmount(c)
                if (v != null) { numScore[i]++; if (v < 0) negScore[i]++ }
                else textLen[i] += c.length.toDouble()
            }
        }
        val dateIdx = dateScore.indices.maxByOrNull { dateScore[it] } ?: return null
        if (dateScore[dateIdx] < sample.size / 2) return null
        val amountIdx = numScore.indices.filter { it != dateIdx && numScore[it] >= sample.size / 2 }
            .maxByOrNull { negScore[it] * 1000 + numScore[it] } ?: return null
        val descIdx = textLen.indices.filter { it != dateIdx && it != amountIdx }.maxByOrNull { textLen[it] }
        return Columns(dateIdx, amountIdx, null, null, null, listOfNotNull(descIdx))
    }

    // ---------- Értékek ----------

    private val ymd = Regex("(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})")
    private val dmy = Regex("(\\d{1,2})[-./](\\d{1,2})[-./](\\d{4})")
    private val compact = Regex("^(\\d{4})(\\d{2})(\\d{2})$")

    fun parseDate(s: String): LocalDate? {
        val t = s.trim()
        try {
            ymd.find(t)?.let { m ->
                val (y, mo, d) = m.destructured
                return LocalDate.of(y.toInt(), mo.toInt(), d.toInt())
            }
            dmy.find(t)?.let { m ->
                val (d, mo, y) = m.destructured
                return LocalDate.of(y.toInt(), mo.toInt(), d.toInt())
            }
            compact.find(t)?.let { m ->
                val (y, mo, d) = m.destructured
                return LocalDate.of(y.toInt(), mo.toInt(), d.toInt())
            }
        } catch (e: Exception) {
            return null
        }
        return null
    }

    fun parseAmount(raw: String): Double? {
        var s = raw.trim()
            .replace(" ", "").replace(" ", "").replace(" ", "")
            .replace("−", "-")
            .replace(Regex("(?i)huf|ft|eur|usd|gbp|chf|[€$£]"), "")
        if (s.isEmpty()) return null
        var neg = false
        if (s.startsWith("(") && s.endsWith(")")) { neg = true; s = s.substring(1, s.length - 1) }
        if (s.startsWith("-")) { neg = !neg; s = s.substring(1) }
        else if (s.startsWith("+")) s = s.substring(1)
        if (s.endsWith("-")) { neg = true; s = s.dropLast(1) }
        s = s.replace("'", "")
        if (s.isEmpty() || !s.matches(Regex("[0-9][0-9.,]*"))) return null
        val lastDot = s.lastIndexOf('.')
        val lastComma = s.lastIndexOf(',')
        val n = when {
            lastDot >= 0 && lastComma >= 0 ->
                if (lastComma > lastDot) s.replace(".", "").replace(',', '.') else s.replace(",", "")
            lastComma >= 0 -> {
                val p = s.split(',')
                if (p.size == 2 && p[1].length != 3) s.replace(',', '.') else s.replace(",", "")
            }
            lastDot >= 0 -> {
                val p = s.split('.')
                if (p.size == 2 && p[1].length != 3) s else s.replace(".", "")
            }
            else -> s
        }
        val v = n.toDoubleOrNull() ?: return null
        return if (neg) -v else v
    }

    private fun normCurrency(s: String?): String {
        val u = s?.trim()?.uppercase().orEmpty()
        return when {
            u.isEmpty() || u == "FT" || u == "HUF" -> "HUF"
            u == "€" || u == "EUR" -> "EUR"
            u == "$" || u == "USD" -> "USD"
            u.length == 3 && u.all { it.isLetter() } -> u
            else -> "HUF"
        }
    }

    // ---------- Tranzakciók ----------

    fun parseTransactions(text: String): List<Transaction> {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.size < 2) return emptyList()
        val delim = detectDelimiter(lines.take(30))
        val rows = lines.map { splitCsv(it, delim) }

        val headerIdx = rows.take(30).indexOfFirst { r ->
            val n = r.map(::norm)
            n.any(::isDateHeader) && (n.any(::isAmountHeader) || n.any(::isDebitHeader))
        }
        val cols = (if (headerIdx >= 0) columnsFromHeader(rows[headerIdx].map(::norm)) else null)
            ?: inferColumns(rows) ?: return emptyList()
        val data = if (headerIdx >= 0) rows.drop(headerIdx + 1) else rows

        data class Raw(val date: LocalDate, val signed: Double, val cur: String, val desc: String, val type: String)

        val raws = data.mapNotNull { r ->
            val date = r.getOrNull(cols.date)?.let(::parseDate) ?: return@mapNotNull null
            val value = if (cols.debit != null) {
                val v = r.getOrNull(cols.debit)?.let(::parseAmount) ?: return@mapNotNull null
                if (v == 0.0) return@mapNotNull null
                -abs(v)
            } else {
                r.getOrNull(cols.amount ?: return@mapNotNull null)?.let(::parseAmount) ?: return@mapNotNull null
            }
            if (value == 0.0) return@mapNotNull null
            val desc = cols.desc.mapNotNull { r.getOrNull(it) }.filter { it.isNotBlank() }.joinToString(" ")
            Raw(date, value, normCurrency(cols.currency?.let { r.getOrNull(it) }), desc, cols.type?.let { r.getOrNull(it) }.orEmpty())
        }
        if (raws.isEmpty()) return emptyList()

        val hasNegative = raws.any { it.signed < 0 }
        val typeAware = cols.type != null && raws.any { it.type.isNotBlank() }
        return raws.mapNotNull { r ->
            val isDebit = when {
                hasNegative -> r.signed < 0
                typeAware -> norm(r.type).let { t -> t.startsWith("t") || "terhel" in t || "debit" in t || "kiad" in t }
                else -> true
            }
            if (!isDebit) null else Transaction(r.date, abs(r.signed), r.cur, r.desc)
        }
    }

    // ---------- Kereskedők ----------

    internal data class Known(val display: String, val patterns: List<String>, val category: Category, val color: Int)

    /** Sorrend számít: a pontosabb minták előbb. */
    internal val KNOWN = listOf(
        Known("Netflix", listOf("NETFLIX"), Category.STREAMING, 2),
        Known("Spotify", listOf("SPOTIFY"), Category.MUSIC, 4),
        Known("YouTube Premium", listOf("YOUTUBE"), Category.STREAMING, 2),
        Known("Google One", listOf("GOOGLE ONE", "GOOGLE *GOOGLE ONE", "GOOGLE STORAGE"), Category.CLOUD, 1),
        Known("Disney+", listOf("DISNEY"), Category.STREAMING, 1),
        Known("HBO Max", listOf("HBO", "MAX.COM", "HBOMAX"), Category.STREAMING, 8),
        Known("SkyShowtime", listOf("SKYSHOWTIME"), Category.STREAMING, 7),
        Known("Amazon Prime", listOf("PRIME VIDEO", "AMAZON PRIME", "AMZN PRIME", "PRIMEVIDEO", "AMAZON DIGITAL"), Category.STREAMING, 0),
        Known("RTL+", listOf("RTL+", "RTL PLUS", "RTLPLUS", "RTL MOST"), Category.STREAMING, 2),
        Known("Apple (iCloud, App Store)", listOf("APPLE.COM", "ITUNES", "APPLE SERVICES"), Category.CLOUD, 1),
        Known("ChatGPT Plus", listOf("OPENAI", "CHATGPT"), Category.SOFTWARE, 5),
        Known("Claude", listOf("ANTHROPIC", "CLAUDE.AI"), Category.SOFTWARE, 3),
        Known("Xbox Game Pass", listOf("XBOX"), Category.GAMES, 4),
        Known("Microsoft 365", listOf("MICROSOFT", "MSFT"), Category.SOFTWARE, 3),
        Known("PlayStation Plus", listOf("PLAYSTATION", "SONY INTERACTIVE", "PSN"), Category.GAMES, 1),
        Known("Nintendo Switch Online", listOf("NINTENDO"), Category.GAMES, 2),
        Known("Google Play", listOf("GOOGLE *", "GOOGLE PLAY", "GOOGLEPLAY"), Category.OTHER, 4),
        Known("Adobe", listOf("ADOBE"), Category.SOFTWARE, 2),
        Known("Canva", listOf("CANVA"), Category.SOFTWARE, 5),
        Known("Dropbox", listOf("DROPBOX"), Category.CLOUD, 1),
        Known("Duolingo", listOf("DUOLINGO"), Category.SOFTWARE, 4),
        Known("Twitch", listOf("TWITCH"), Category.STREAMING, 8),
        Known("Deezer", listOf("DEEZER"), Category.MUSIC, 8),
        Known("Tidal", listOf("TIDAL"), Category.MUSIC, 7),
        Known("Audible", listOf("AUDIBLE"), Category.NEWS, 3),
        Known("Storytel", listOf("STORYTEL"), Category.NEWS, 3),
        Known("LinkedIn Premium", listOf("LINKEDIN"), Category.SOFTWARE, 1),
        Known("Tinder", listOf("TINDER"), Category.OTHER, 6),
        Known("Wolt+", listOf("WOLT+", "WOLT PLUS"), Category.OTHER, 1),
        Known("Telekom", listOf("TELEKOM"), Category.UTILITIES, 6),
        Known("One (Vodafone)", listOf("VODAFONE", "ONE HUNGARY", "ONE MAGYARORSZAG"), Category.UTILITIES, 2),
        Known("Yettel", listOf("YETTEL", "TELENOR"), Category.UTILITIES, 5),
        Known("Digi", listOf("DIGI TAVKOZLESI", "DIGI KFT", "DIGI "), Category.UTILITIES, 1),
        Known("Revolut csomag", listOf("REVOLUT PREMIUM", "REVOLUT METAL", "REVOLUT PLUS", "PLAN FEE"), Category.OTHER, 7),
    )

    private val STOP = setOf(
        "VASARLAS", "KARTYA", "KARTYAS", "BANKKARTYAS", "BANKKARTYA", "POS", "TRANZAKCIO", "TERHELES",
        "INTERNETES", "ONLINE", "PAYMENT", "CARD", "PURCHASE", "DATUM", "DATE", "HUF", "EUR", "USD",
        "KARTYASZAM", "VISA", "MASTERCARD", "MAESTRO", "DEBIT", "CREDIT", "KONYVELT", "KONYVELES",
        "JOVAIRAS", "ATUTALAS", "ERTEKNAP", "SZAMLA", "WWW", "COM", "KFT", "ZRT", "NYRT", "LTD", "INC",
        "LLC", "GMBH", "PAYPAL", "SUMUP", "BUDAPEST", "HUN", "IRL", "NLD", "LUX", "GBR", "USA", "DEU",
        "ELSZAMOLAS", "FOGLALAS", "ZAROLAS", "EGYEB", "TRANSFER", "TO", "FROM", "THE", "AND", "SZAMLAROL",
        "ESETI", "ALLANDO", "MEGBIZAS", "CSOPORTOS", "BESZEDES", "KOZLEMENY", "PARTNER", "NEV",
        "APPLE", "GOOGLE", "PAY", "CONTACTLESS", "ERINTES", "NELKULI", "WEB", "INTERNET", "VASARLASI",
    )

    private data class Merchant(val key: String, val display: String, val known: Known?)

    private fun merchantOf(desc: String): Merchant? {
        val up = norm(desc).uppercase()
        KNOWN.firstOrNull { k -> k.patterns.any { it in up } }?.let { return Merchant(it.display, it.display, it) }
        val tokens = up.split(Regex("[^A-Z+]+"))
            .filter { it.length >= 3 && it !in STOP }
        if (tokens.isEmpty()) return null
        val words = tokens.take(2)
        val display = words.joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }
        return Merchant(words.joinToString(" "), display, null)
    }

    // ---------- Felismerés ----------

    internal fun cycleFor(days: Int): Cycle? = when (days) {
        in 5..9 -> Cycle.WEEKLY
        in 25..36 -> Cycle.MONTHLY
        in 80..100 -> Cycle.QUARTERLY
        in 340..390 -> Cycle.YEARLY
        else -> null
    }

    internal fun fits(days: Int, c: Cycle): Boolean = when (c) {
        Cycle.WEEKLY -> days in 5..9
        Cycle.MONTHLY -> days in 25..36
        Cycle.QUARTERLY -> days in 80..100
        Cycle.YEARLY -> days in 340..390
    }

    internal fun median(xs: List<Double>): Double {
        val s = xs.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }

    fun detect(tx: List<Transaction>, today: LocalDate): List<ImportCandidate> {
        val groups = tx.mapNotNull { t -> merchantOf(t.description)?.let { it to t } }
            .groupBy({ it.first.key + "|" + it.second.currency }, { it })

        val result = ArrayList<ImportCandidate>()
        for ((_, items) in groups) {
            val merchant = items.first().first
            val known = merchant.known
            // naponként egy terhelés (azonos napon több tétel ugyanattól: a legnagyobb)
            val charges = items.map { it.second }
                .groupBy { it.date }
                .map { (_, sameDay) -> sameDay.maxByOrNull { it.amount }!! }
                .sortedBy { it.date }
            val currency = charges.first().currency
            val last = charges.last()

            var cycle: Cycle
            var confident: Boolean
            var hint: String? = null

            if (charges.size >= 2) {
                val gaps = charges.zipWithNext { a, b -> ChronoUnit.DAYS.between(a.date, b.date).toInt() }
                val med = median(gaps.map { it.toDouble() }).toInt()
                val detected = cycleFor(med)
                val amounts = charges.map { it.amount }
                val medAmount = median(amounts)
                val similar = amounts.count { abs(it - medAmount) <= medAmount * 0.2 } >= amounts.size * 0.7
                val regular = detected != null && gaps.count { fits(it, detected) } >= gaps.size * 0.7
                if (detected != null && regular && similar) {
                    cycle = detected
                    confident = true
                } else if (known != null) {
                    cycle = detected ?: Cycle.MONTHLY
                    confident = false
                    hint = "Nem teljesen rendszeres, ellenőrizd az összeget és a gyakoriságot"
                } else continue
            } else {
                if (known == null) continue
                confident = false
                if (ChronoUnit.DAYS.between(last.date, today) > 40) {
                    cycle = Cycle.YEARLY
                    hint = "Csak 1 terhelést találtam, valószínűleg éves előfizetés"
                } else {
                    cycle = Cycle.MONTHLY
                    hint = "Csak 1 terhelést találtam, ellenőrizd a gyakoriságot"
                }
            }

            // Ha rég nem volt terhelés, valószínűleg már lemondta.
            val expectedNext = cycle.add(last.date, 1)
            if (ChronoUnit.DAYS.between(expectedNext, today) > 20) {
                confident = false
                hint = "Már egy ideje nem volt terhelés, lehet, hogy lemondtad"
            }

            var next = expectedNext
            var k = 1L
            while (next.isBefore(today)) { k++; next = cycle.add(last.date, k) }

            result += ImportCandidate(
                name = merchant.display,
                price = last.amount,
                currency = currency,
                cycle = cycle,
                lastCharge = last.date,
                nextCharge = next,
                count = charges.size,
                category = known?.category ?: Category.OTHER,
                colorIndex = known?.color ?: (abs(merchant.key.hashCode()) % 9),
                confident = confident,
                hint = hint,
            )
        }
        return result.sortedWith(
            compareByDescending<ImportCandidate> { it.confident }.thenByDescending { it.monthlyCost }
        )
    }
}
