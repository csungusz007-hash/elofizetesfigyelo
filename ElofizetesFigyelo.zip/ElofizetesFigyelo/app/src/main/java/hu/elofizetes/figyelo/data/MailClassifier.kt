package hu.elofizetes.figyelo.data

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** Egy e-mail a feldolgozáshoz (csak a telefonon). */
data class MailItem(
    val from: String,
    val subject: String,
    val date: LocalDate,
    val body: String,
)

/**
 * E-mailekből (számlák, előfizetési és próbaidős levelek) előfizetéseket keres.
 * Tiszta Kotlin, hálózat nélkül tesztelhető.
 */
object MailClassifier {

    private data class Hit(
        val service: String,
        val known: StatementImporter.Known?,
        val date: LocalDate,
        val amount: Double?,
        val currency: String,
        val cycleHint: Cycle?,
        val isTrial: Boolean,
        val trialEnd: LocalDate?,
        val isCharge: Boolean,
        val cancelled: Boolean,
        val nextHint: LocalDate?,
    )

    private fun norm(s: String) = StatementImporter.norm(s)

    // ---------- HTML → szöveg ----------

    fun htmlToText(html: String): String {
        var t = html
            .replace(Regex("(?is)<(style|script|head)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</tr>|</li>|</h\\d>"), "\n")
            .replace(Regex("(?s)<[^>]+>"), " ")
        t = t.replace("&nbsp;", " ").replace("&#160;", " ").replace("&amp;", "&")
            .replace("&euro;", "€").replace("&#8364;", "€").replace("&#36;", "$")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        t = Regex("&#(\\d{2,5});").replace(t) { m -> m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: " " }
        return t.replace(Regex("[ \\t\\u00A0]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n")
    }

    // ---------- Kulcsszavak (ékezet nélkül, kisbetűvel) ----------

    private val SUBS = listOf(
        "subscription", "elofizetes", "membership", "tagsag", "renew", "megujit", "megujul",
        "recurring", "ismetlodo", "premium", "csomag", "your plan",
    )
    private val RECEIPT = listOf(
        "receipt", "nyugta", "szamla", "invoice", "payment", "fizetes", "charged", "terhel",
        "order", "rendeles", "purchase", "vasarlas", "billing", "szamlazas", "paid", "kifizet",
    )
    private val MARKETING = listOf(
        "%", "akcio", "ajanlat", "offer", "deal", "sale", "kedvezmeny", "discount", "newsletter",
        "hirlevel", "webinar", "tips", "tippek", "new feature", "ujdonsag",
    )
    private val CANCEL = listOf(
        "cancel", "lemond", "megszunt", "has ended", "expired", "lejart", "megszuntet", "unsubscribed",
    )
    private val TRIAL = Regex(
        "free trial|trial (ends|will end|expires|period)|your trial|trial started|start(ed)? your trial|" +
            "probaido|probaidoszak|ingyenes idoszak|probaverzio|ingyenes proba"
    )
    private val NEXT_WORDS = Regex(
        "next (billing|payment|charge|renewal)|renews on|will renew|renewal date|billing date|" +
            "kovetkezo (terheles|fizetes|szamlazas|megujitas)|megujul|megujitas datuma"
    )

    // ---------- Dátumok ----------

    private val MONTHS = mapOf(
        "jan" to 1, "january" to 1, "januar" to 1,
        "feb" to 2, "febr" to 2, "february" to 2, "februar" to 2,
        "mar" to 3, "marc" to 3, "march" to 3, "marcius" to 3,
        "apr" to 4, "april" to 4, "aprilis" to 4,
        "may" to 5, "maj" to 5, "majus" to 5,
        "jun" to 6, "june" to 6, "junius" to 6,
        "jul" to 7, "july" to 7, "julius" to 7,
        "aug" to 8, "august" to 8, "augusztus" to 8,
        "sep" to 9, "sept" to 9, "szept" to 9, "september" to 9, "szeptember" to 9,
        "oct" to 10, "okt" to 10, "october" to 10, "oktober" to 10,
        "nov" to 11, "november" to 11,
        "dec" to 12, "december" to 12,
    )

    private val DATE_PATTERNS = listOf(
        // 2026. december 3.
        Regex("(\\d{4})\\.?\\s*([a-z]{3,10})\\.?\\s*(\\d{1,2})\\b") to "ymd_name",
        // December 3, 2026
        Regex("\\b([a-z]{3,10})\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?,?\\s+(\\d{4})") to "mdy_name",
        // 3 December 2026
        Regex("\\b(\\d{1,2})(?:st|nd|rd|th)?\\.?\\s+([a-z]{3,10})\\.?,?\\s+(\\d{4})") to "dmy_name",
        // 2026-12-03 vagy 2026.12.03.
        Regex("\\b(\\d{4})[-.]\\s?(\\d{1,2})[-.]\\s?(\\d{1,2})\\b") to "ymd",
    )

    private data class Dated(val pos: Int, val date: LocalDate)

    private fun findDates(lower: String): List<Dated> {
        val out = ArrayList<Dated>()
        for ((re, kind) in DATE_PATTERNS) {
            for (m in re.findAll(lower)) {
                val g = m.groupValues
                val d = runCatching {
                    when (kind) {
                        "ymd_name" -> MONTHS[g[2]]?.let { LocalDate.of(g[1].toInt(), it, g[3].toInt()) }
                        "mdy_name" -> MONTHS[g[1]]?.let { LocalDate.of(g[3].toInt(), it, g[2].toInt()) }
                        "dmy_name" -> MONTHS[g[2]]?.let { LocalDate.of(g[3].toInt(), it, g[1].toInt()) }
                        else -> LocalDate.of(g[1].toInt(), g[2].toInt(), g[3].toInt())
                    }
                }.getOrNull()
                if (d != null && d.year in 2015..2100) out += Dated(m.range.first, d)
            }
        }
        return out.sortedBy { it.pos }
    }

    /** Az első dátum egy kulcsszó után (max. 160 karakteren belül), ami nem korábbi a levélnél. */
    private fun dateAfter(lower: String, keyword: Regex, notBefore: LocalDate, dates: List<Dated>): LocalDate? {
        for (m in keyword.findAll(lower)) {
            val d = dates.firstOrNull { it.pos >= m.range.first && it.pos - m.range.last <= 160 && !it.date.isBefore(notBefore) }
            if (d != null) return d.date
        }
        return null
    }

    // ---------- Összegek ----------

    private const val NUM = "\\d{1,3}(?:[ .,\\u00A0]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?"
    private val AMOUNT_BEFORE = Regex("(HUF|Ft|EUR|€|USD|US\\$|\\$)\\s?($NUM)(?![\\d])")
    private val AMOUNT_AFTER = Regex("(?<![\\d.,])($NUM)\\s?(Ft|HUF|EUR|€|USD|\\$)")
    private val AMOUNT_WORDS = Regex(
        "(?i)total|osszesen|összesen|vegosszeg|végösszeg|fizetendo|fizetendő|amount|price|ár:|charged|terhel|" +
            "per month|/month|/mo|havonta|havi díj|per year|/year|évente|then"
    )

    private data class Money(val pos: Int, val value: Double, val currency: String)

    private fun currencyOf(s: String) = when (s.uppercase()) {
        "FT", "HUF" -> "HUF"
        "€", "EUR" -> "EUR"
        "$", "US$", "USD" -> "USD"
        else -> "HUF"
    }

    private fun findAmounts(text: String): List<Money> {
        val out = ArrayList<Money>()
        for (m in AMOUNT_BEFORE.findAll(text)) {
            StatementImporter.parseAmount(m.groupValues[2])?.let { out += Money(m.range.first, it, currencyOf(m.groupValues[1])) }
        }
        for (m in AMOUNT_AFTER.findAll(text)) {
            StatementImporter.parseAmount(m.groupValues[1])?.let { out += Money(m.range.first, it, currencyOf(m.groupValues[2])) }
        }
        return out.filter { it.value > 0 && it.value < 1_000_000 }.sortedBy { it.pos }
    }

    private fun pickAmount(text: String): Money? {
        val all = findAmounts(text)
        if (all.isEmpty()) return null
        for (k in AMOUNT_WORDS.findAll(text)) {
            all.firstOrNull { it.pos >= k.range.first && it.pos - k.range.last <= 80 }?.let { return it }
        }
        return all.first()
    }

    private fun cycleHint(lower: String): Cycle? = when {
        Regex("yearly|annual|annually|per year|/year|/yr|evente|eves (elofizetes|csomag|dij)|1 ev").containsMatchIn(lower) -> Cycle.YEARLY
        Regex("quarterly|negyedev").containsMatchIn(lower) -> Cycle.QUARTERLY
        Regex("weekly|per week|/week|hetente|heti (elofizetes|dij)").containsMatchIn(lower) -> Cycle.WEEKLY
        Regex("monthly|per month|/month|/mo\\b|havonta|havi (elofizetes|dij|csomag)|1 honap").containsMatchIn(lower) -> Cycle.MONTHLY
        else -> null
    }

    // ---------- Szolgáltatás ----------

    private val APPLE_SUB = listOf(
        "ICLOUD" to "iCloud+", "APPLE MUSIC" to "Apple Music", "APPLE TV" to "Apple TV+",
        "APPLE ONE" to "Apple One", "ARCADE" to "Apple Arcade",
    )

    private fun serviceOf(from: String, subject: String, body: String): Pair<String, StatementImporter.Known?>? {
        val head = norm("$from $subject").uppercase()
        val bodyUp = norm(body.take(3000)).uppercase()
        var known = StatementImporter.KNOWN.firstOrNull { k -> k.patterns.any { it in head } }
        if (known != null && (known.display.startsWith("Apple") || known.display == "Google Play")) {
            // Gyűjtő-számla: a levélből próbáljuk kideríteni a konkrét szolgáltatást.
            val specific = StatementImporter.KNOWN.firstOrNull { k ->
                k !== known && !k.display.startsWith("Apple") && k.display != "Google Play" &&
                    k.patterns.any { p -> p.length >= 5 && p in bodyUp }
            }
            if (specific != null) return specific.display to specific
            if (known.display.startsWith("Apple")) {
                APPLE_SUB.firstOrNull { it.first in bodyUp }?.let { return it.second to known }
            }
        }
        if (known != null) return known.display to known
        // Ismeretlen feladó: a megjelenített név vagy a domain.
        val name = from.substringBefore("<").trim().trim('"').substringBefore("@").trim()
        val domain = Regex("@([A-Za-z0-9-]+\\.)*([A-Za-z0-9-]+)\\.[A-Za-z]{2,}").find(from)?.groupValues?.get(2)
        val label = when {
            name.length in 2..40 && !name.contains("noreply", true) && !name.contains("no-reply", true) -> name
            !domain.isNullOrBlank() -> domain.replaceFirstChar { it.uppercase() }
            else -> return null
        }
        known = null
        return label to known
    }

    // ---------- Egy levél ----------

    private fun classify(m: MailItem): Hit? {
        val subjLower = norm(m.subject)
        val lower = norm(m.subject + "\n" + m.body)
        val svc = serviceOf(m.from, m.subject, m.body) ?: return null
        val (service, known) = svc

        val isTrial = TRIAL.containsMatchIn(lower)
        val cancelled = CANCEL.any { it in subjLower }
        val receiptish = RECEIPT.any { it in lower }
        val subsish = SUBS.any { it in lower }
        val marketing = MARKETING.any { it in subjLower } && RECEIPT.none { it in subjLower }

        if (known == null && !(SUBS.any { it in subjLower } || TRIAL.containsMatchIn(subjLower))) return null
        if (marketing && !isTrial && !cancelled) return null

        val money = pickAmount(m.subject + "\n" + m.body)
        val dates = findDates(lower)
        val trialEnd = if (isTrial) {
            dateAfter(lower, TRIAL, m.date, dates)
                ?: dates.firstOrNull { it.date.isAfter(m.date) && ChronoUnit.DAYS.between(m.date, it.date) <= 120 }?.date
        } else null
        val nextHint = dateAfter(lower, NEXT_WORDS, m.date, dates)
        val isCharge = !isTrial && money != null && (receiptish || subsish)

        if (!isTrial && !isCharge && !cancelled) return null
        return Hit(
            service = service,
            known = known,
            date = m.date,
            amount = money?.value,
            currency = money?.currency ?: "HUF",
            cycleHint = cycleHint(lower),
            isTrial = isTrial,
            trialEnd = trialEnd,
            isCharge = isCharge,
            cancelled = cancelled,
            nextHint = nextHint,
        )
    }

    // ---------- Összesítés szolgáltatásonként ----------

    fun detect(mails: List<MailItem>, today: LocalDate): List<ImportCandidate> {
        val hits = mails.mapNotNull { runCatching { classify(it) }.getOrNull() }
        val out = ArrayList<ImportCandidate>()

        for ((_, list) in hits.groupBy { it.service.lowercase() }) {
            val sorted = list.sortedBy { it.date }
            val latest = sorted.last()
            if (latest.cancelled) continue
            val known = sorted.firstNotNullOfOrNull { it.known }
            val category = known?.category ?: Category.OTHER
            val color = known?.color ?: (abs(latest.service.hashCode()) % 9)
            val trialHit = sorted.lastOrNull { it.isTrial }
            val charges = sorted.filter { it.isCharge && (it.amount ?: 0.0) > 0 }
            val chargedAfterTrial = trialHit != null && charges.any { it.date.isAfter(trialHit.date) }

            if (trialHit != null && !chargedAfterTrial) {
                val end = trialHit.trialEnd ?: trialHit.date.plusDays(30)
                val price = trialHit.amount ?: charges.lastOrNull()?.amount ?: 0.0
                val currency = if (trialHit.amount != null) trialHit.currency else charges.lastOrNull()?.currency ?: "HUF"
                val cycle = trialHit.cycleHint ?: Cycle.MONTHLY
                if (end.isBefore(today.minusDays(2))) {
                    // Lejárt próbaidő, de terhelést nem láttunk: valószínűleg fizetős lett.
                    var next = end
                    while (next.isBefore(today)) next = cycle.add(next, 1)
                    out += ImportCandidate(
                        latest.service, price, currency, cycle, end, next, 0, category, color,
                        confident = false,
                        hint = "A próbaidő lejárt. Ha nem mondtad le, már fizetős lehet",
                    )
                } else {
                    out += ImportCandidate(
                        latest.service, price, currency, cycle, trialHit.date, end, 0, category, color,
                        confident = trialHit.trialEnd != null,
                        hint = when {
                            trialHit.trialEnd == null -> "A próbaidő végét nem találtam, ellenőrizd a dátumot"
                            price <= 0.0 -> "A próbaidő utáni árat nem találtam, add meg"
                            else -> null
                        },
                        trial = true,
                    )
                }
                continue
            }

            if (charges.isEmpty()) continue
            val last = charges.last()
            val currency = last.currency
            val dates = charges.map { it.date }.distinct()
            var confident: Boolean
            var hint: String? = null
            val cycle: Cycle
            if (dates.size >= 2) {
                val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }
                val detected = StatementImporter.cycleFor(StatementImporter.median(gaps.map { it.toDouble() }).toInt())
                val regular = detected != null && gaps.count { StatementImporter.fits(it, detected) } >= gaps.size * 0.7
                cycle = if (regular) detected!! else (last.cycleHint ?: detected ?: Cycle.MONTHLY)
                confident = regular || last.cycleHint != null
                if (!confident) hint = "Nem teljesen rendszeres, ellenőrizd a gyakoriságot"
            } else {
                cycle = last.cycleHint ?: if (ChronoUnit.DAYS.between(last.date, today) > 40) Cycle.YEARLY else Cycle.MONTHLY
                confident = known != null && last.cycleHint != null
                if (!confident) hint = "Csak 1 számlát találtam, ellenőrizd a gyakoriságot"
            }
            if (known == null && dates.size < 2) confident = false

            val expected = cycle.add(last.date, 1)
            var next = last.nextHint?.takeIf { !it.isBefore(today) } ?: expected
            while (next.isBefore(today)) next = cycle.add(next, 1)
            if (last.nextHint == null && ChronoUnit.DAYS.between(expected, today) > 20) {
                confident = false
                hint = "Már egy ideje nem jött számla, lehet, hogy lemondtad"
            }

            out += ImportCandidate(
                name = latest.service,
                price = last.amount ?: 0.0,
                currency = currency,
                cycle = cycle,
                lastCharge = last.date,
                nextCharge = next,
                count = dates.size,
                category = category,
                colorIndex = color,
                confident = confident,
                hint = hint,
            )
        }
        return out.sortedWith(
            compareByDescending<ImportCandidate> { it.trial }
                .thenByDescending { it.confident }
                .thenByDescending { it.monthlyCost }
        )
    }
}
