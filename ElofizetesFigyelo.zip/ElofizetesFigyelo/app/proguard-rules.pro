# A WorkManager a workert reflexióval példányosítja.
-keep class hu.elofizetes.figyelo.ReminderWorker { *; }
